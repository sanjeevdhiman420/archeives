jQuery(document).ready(function(){
    jQuery('#menu-item-2444').css('margin-left', '1px');
    });
    jQuery(document).ready(function(){
    jQuery('#menu-item-2442').css('margin-left', '12px');
    });
     jQuery(document).ready(function(){
    jQuery('#menu-footer-menu-3').css('display', 'none');
    });
//   var x = window.location.href;
// if(x == "https://cgiviz.com/projects/"){
// window.location.replace('https://cgiviz.com/portfolio/42-rochester-ave/');
// }
//jQuery('#media_image-1 img').attr('src', 'https://secureservercdn.net/198.71.233.203/k69.2dc.myftpupload.com/wp-content/uploads/2021/12/cvig-logo-light.svg?time=1640760366');
jQuery(".d-flex.align-items-center.justify-content-center a").attr("href", "https://cgiviz.com/projects/");
//add link to project article
jQuery(document).ready(function(){
jQuery(".entry-details__inner").hover(function(){
jQuery(this).wrap('<a class="entry-details__inner" href=""></a>');
let x = jQuery(this).find('a').attr('href');
jQuery(this).parent().attr('href', x);
});
});


  