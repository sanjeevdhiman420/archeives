<?php

add_action('wp_enqueue_scripts', 'vara_child_theme_styles', PHP_INT_MAX);
function vara_child_theme_styles() {
	wp_enqueue_style('parent-style', get_template_directory_uri(). '/style.css');
	wp_enqueue_style( 'my-style', get_stylesheet_directory_uri() . '/style.css', false, '1.0', 'all' );
	wp_enqueue_script( "script", get_stylesheet_directory_uri() . '/script.js', array(), '1.0.0', true );
	wp_enqueue_script( 'my-fonts', get_stylesheet_directory_uri().'/assets/fonts/Montserrat-Italic-VariableFont_wght.ttf', true );
	wp_enqueue_script( 'my-fonts-1', get_stylesheet_directory_uri().'/assets/fonts/Montserrat-VariableFont_wght.ttf', true );

	}

