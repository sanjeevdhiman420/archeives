<?php
/**
 * Searchform
 */
?>
<form action="<?php echo esc_url(home_url('/')) ?>" method="get" class="search-form">
	<input placeholder="<?php echo esc_attr__('Search...', 'vara') ?>" type="search" name="s" />
	<label class="search-form-button">
		<input type="submit" />
        <svg width="20" height="20" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11.9167 20.5833C16.7031 20.5833 20.5833 16.7031 20.5833 11.9167C20.5833 7.1302 16.7031 3.25 11.9167 3.25C7.1302 3.25 3.25 7.1302 3.25 11.9167C3.25 16.7031 7.1302 20.5833 11.9167 20.5833Z" stroke="black" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M22.75 22.75L18.0375 18.0375" stroke="black" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
	</label>
</form>
