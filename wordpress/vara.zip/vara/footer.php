        </div>
        <?php
        /**
         * Init
         */
        $vara_footer_class = ['gs-site-footer'];
        $vara_footer_template_class = ['gs-footer-template'];

        /**
         * Type
         */
        $vara_footer_type = vara_inherit_option('footer_type', 'footer_type', '1');
        $vara_footer_template = '';
        if (get_field('footer_type', get_queried_object()) == '1') {
	        $vara_footer_template = get_theme_mod('footer_template');
        } elseif (get_field('footer_type', get_queried_object()) == '3' && get_field('footer_template')) {
	        $vara_footer_template = get_field('footer_template');
        } else {
	        $vara_footer_template = get_theme_mod('footer_template');
        }

        /**
         * Parallax
         */
        if (vara_inherit_option('footer_parallax', 'footer_parallax', '2') == '1') {
            $vara_footer_class[] = 'site-footer-sticky';
            $vara_footer_template_class[] = 'site-footer-sticky';
        }
        ?>
        <?php if (apply_filters('vara_display_footer', true) && $vara_footer_type != '2') : ?>
            <?php
            // Skin
            if (vara_inherit_option('footer_skin', 'footer_skin', '1') == '1') {
                $vara_footer_class[] = 'site-footer-dark';
            } else {
                $vara_footer_class[] = 'site-footer-light';
            }

            // Container
            if (vara_inherit_option('footer_container', 'footer_container', '1') == '2') {
                $vara_footer_class[] = 'gs-site-footer--wide-container';
            }
            ?>
            <footer class="<?php echo esc_attr(implode(' ', $vara_footer_class)) ?>">
                <?php get_template_part('tpls/footer/widgets') ?>

                <?php get_template_part('tpls/footer/copyright') ?>
            </footer>
        <?php endif;

        // Elementor
        if ($vara_footer_type == '2' && $vara_footer_template) :
            ?>
            <footer class="<?php echo esc_attr(implode(' ', $vara_footer_template_class)) ?>">
                <?php echo vara_get_custom_template($vara_footer_template) ?>
            </footer>
        <?php endif; ?>

        <?php get_template_part('tpls/extra/to-top') ?>

	</div>  <!-- /.site-content -->

	<?php wp_footer(); ?>
</body>
</html>