<?php
global $wp_query;

/**
 * Portfolio Category
 */
get_header();

get_template_part('tpls/hero/taxonomy');

/**
 * Meta
 */
set_query_var('grada_portfolio_meta_thumbnail', 'yes');
set_query_var('grada_portfolio_meta_title', 'yes');
set_query_var('grada_portfolio_meta_categories', 'yes');
set_query_var('grada_portfolio_meta_icon', false);
set_query_var('grada_portfolio_thumbnail_resizer', false);
set_query_var('grada_portfolio_carousel_height', 'auto');

/**
 * Hover Visibility and Hover Animation
 */
set_query_var('grada_portfolio_hover_visibility', 'show');

/**
 * Hover
 */
set_query_var('grada_portfolio_style_hover_active', 'no');
set_query_var('grada_portfolio_style_hover_meta_vertical_alignment', 'center');
set_query_var('grada_portfolio_style_hover_type', 'bottom');

$grada_portfolio_category_id = uniqid();
/**
 * Breadcrumb
 */
$vara_page_breadcrumb = vara_inherit_option('general_archive_breadcrumb', 'breadcrumbs_archives_visibility', '2');
vara_breadcrumbs($vara_page_breadcrumb, get_theme_mod('breadcrumbs_separator'));

do_action('vara_open_container');
?>
<div class="gs-portfolio-wrapper large-pt large-pb">
    <div class="gs-portfolio-list gs-portfolio-list--meta-overlay">
        <div class="row isotope-container" data-entries-id="<?php echo esc_attr( $grada_portfolio_category_id ); ?>">
            <?php while (have_posts()) : the_post(); ?>
                <article class="iso-item col-sm-6 col-md-4" id="id-<?php the_ID() ?>" data-entry-id="<?php the_ID() ?>">
                    <?php get_template_part('tpls/portfolio/style/meta-overlay')  ?>
                </article>
            <?php endwhile; ?>
        </div>
        <?php grada_paging_navigation($wp_query); ?>
    </div>
</div>
<?php
do_action('vara_close_container');

get_footer();