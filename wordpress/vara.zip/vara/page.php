<?php
/**
 * Page
 */
get_header();

get_template_part('tpls/hero/standard');

/**
 * Breadcrumb
 */
$vara_page_breadcrumb = vara_inherit_option('general_breadcrumb', 'breadcrumbs_page_visibility', '1');
vara_breadcrumbs($vara_page_breadcrumb, get_theme_mod('breadcrumbs_separator'));

/**
 * Page Title
 */
$vara_general_title = vara_inherit_option('general_title', 'general_title_page', '2');
$vara_main_wrapper_class = '';

if ($vara_general_title != '1') {
	$vara_main_wrapper_class = 'large-pt';
}

if ($vara_general_title == '1') :
	?>
    <div class="gs-page-title-wrapper huge-pt huge-pb">
        <div class="container">
			<?php the_title('<h2 class="gs-page-title">', '</h2>') ?>
        </div>
    </div>
<?php endif; ?>
    <div class="content-wrapper-holder gs-cl large-pb <?php echo esc_attr($vara_main_wrapper_class) ?>">
        <div class="container content-wrapper-inner">
			<?php
			if (have_posts()) {
				while (have_posts()) {
					the_post();
					the_content();
					wp_link_pages(array('before' => '<div class="gs-pagination gs-pagination-pages"><span class="gs-pages-title">' . esc_attr__( 'Pages:', 'vara' ) . '</span><div class="gs-pagination-pages__numbers">', 'after' => '</div></div>'));
					paginate_links();
				}
			}
			?>
        </div>
    </div>
<?php
comments_template();

get_footer();