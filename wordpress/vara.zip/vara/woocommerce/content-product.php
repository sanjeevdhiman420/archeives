<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product, $vara_data_wow_seconds, $vara_data_wow_delay;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

/**
 * Type
 */
$vara_shop_type = get_theme_mod('shop_type', 'classic-grid');

/**
 * Columns
 * 
 * It changes the columns via the selector
 * item class.
 */
$vara_shop_selector_class = 'iso-item';

switch (get_theme_mod('shop_columns', '2-columns')) {
    case '1-column':
        $vara_shop_selector_class .= ' col-12';
        break;
    default:
        $vara_shop_selector_class .= ' col-sm-6';
        break;
    case '3-columns':
        $vara_shop_selector_class .= ' col-md-4 col-sm-6';
        break;
    case '4-columns':
        $vara_shop_selector_class .= ' col-md-3 col-sm-6';
        break;
}

/**
 * Related Products Columns
 * 
 * Override the columns of the
 * related products in product.
 */
if (is_single()) {
    switch (vara_inherit_option('product_related_count', 'product_related_count', '4')) {
        case '1':
            $vara_shop_selector_class = 'iso-item col-12';
            break;
        case '2':
            $vara_shop_selector_class = 'iso-item col-sm-6';
            break;
        case '3':
            $vara_shop_selector_class = 'iso-item col-md-4 col-sm-6';
            break;
        default:
            $vara_shop_selector_class = 'iso-item col-md-3 col-sm-6';
            break;
    }
}

/**
 * Spacing
 * 
 * It's used for the spacing 
 * between shop products.
 */
$vara_shop_spacing = get_theme_mod('shop_spacing', 'no');
$vara_shop_spacing_value = get_theme_mod('shop_spacing_value', 30);

$vara_shop_spacing_bool = $vara_shop_spacing == 'yes' || $vara_shop_spacing_value == '0' ? true : false;
$vara_shop_spacing_selector = $vara_shop_spacing_product = null;

if ($vara_shop_spacing == 'yes' && $vara_shop_spacing_value) {
    $vara_shop_spacing_selector = 'padding-left: '. $vara_shop_spacing_value / 2 .'px; padding-right: '. $vara_shop_spacing_value / 2 .'px';
    $vara_shop_spacing_product = 'margin-bottom: '. $vara_shop_spacing_value .'px';
} elseif ($vara_shop_spacing == 'yes' && $vara_shop_spacing_value == '0') {
    $vara_shop_spacing_selector = 'padding-left: 0; padding-right: 0';
    $vara_shop_spacing_product = 'margin-bottom: 0';
}

/**
 * Meta
 */
set_query_var('grada_products_meta_thumbnail', 'yes');
set_query_var('grada_products_meta_title', 'yes');
set_query_var('grada_products_meta_price', 'yes');
set_query_var('grada_products_meta_categories', 'yes');
set_query_var('grada_products_meta_results_count', 'yes');
set_query_var('grada_products_carousel_height', 'auto');
set_query_var('grada_products_meta_excerpt', 'no');

if ( $vara_shop_type == 'left-image' ) {
    set_query_var( 'grada_products_meta_excerpt', 'no' );
}

/**
 * Thumbnail Sizes
 * 
 * It checks if the content-product is being
 * used in a single(product), if yes the values
 * will be inherit from the product settings
 */
$grada_shop_thumbnail = is_single() ? get_theme_mod('product_thumbnail_resizer', 'no') : get_theme_mod('shop_thumbnail_resizer', 'no');
$grada_shop_thumbnail_sizes = is_single() ? get_theme_mod('product_thumbnail_sizes', 'medium') : get_theme_mod('shop_thumbnail_sizes', 'medium');
$grada_shop_thumbnail_output = null;

if ($grada_shop_thumbnail == 'yes') {
	foreach (get_intermediate_image_sizes() as $image_size) {
		$grada_shop_thumbnail_output[$image_size] = $image_size;
	}
	$grada_shop_thumbnail_output = $grada_shop_thumbnail_output[$grada_shop_thumbnail_sizes];
}
set_query_var('grada_products_thumbnail_resizer', $grada_shop_thumbnail_output);

/**
 * Animation & WOW Delay
 */
$vara_shop_animation = get_theme_mod('shop_animation', 'fade-in');
$vara_shop_product_holder_class = 'product-holder';

if ($vara_shop_animation == 'fade-in' || $vara_shop_animation == 'fade-in-delay') {
    $vara_shop_product_holder_class .= ' gsFadeIn wow';
} elseif ($vara_shop_animation == 'fade-in-up' || $vara_shop_animation == 'fade-in-up-delay') {
    $vara_shop_product_holder_class .= ' gsFadeInUp wow';
}

$vara_wow_holder = "data-wow-delay=". $vara_data_wow_seconds/10 ."s";

/**
 * Override Related Products Type
 */
if (is_single() || is_cart()) {
    $vara_shop_type = 'classic-grid';
}
?>
<article <?php wc_product_class($vara_shop_selector_class); ?> data-id="<?php the_ID(); ?>" <?php echo wp_kses_post($vara_shop_spacing_bool ? 'style="'. $vara_shop_spacing_selector .'"' : '') ?>>
	<div class="<?php echo esc_attr($vara_shop_product_holder_class) ?>" <?php echo esc_attr($vara_data_wow_delay === true && $vara_data_wow_seconds ? $vara_wow_holder : ''); ?> <?php echo wp_kses_post($vara_shop_spacing_bool ? 'style="'. $vara_shop_spacing_product .'"' : '') ?>>
		<?php
		/**
		 * Layout Type
		 */
		get_template_part('tpls/shop/style/' . $vara_shop_type );
		?>
	</div>
</article>
