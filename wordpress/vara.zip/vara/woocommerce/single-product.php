<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header(); 

get_template_part('tpls/hero/standard');

/**
 * Sidebar
 */
$vara_sidebar_option = vara_inherit_option('product_sidebar', 'product_sidebar', '3');
$vara_row_class = 'row';
$vara_product_class = 'col-lg-8';
$vara_sidebar_class = 'col-lg-4';

if ($vara_sidebar_option == '1') {
    $vara_row_class .= ' flex-row-reverse';
} elseif ($vara_sidebar_option == '3') {
	$vara_product_class = 'col-12';
	$vara_sidebar_class = 'gs-d-none';
}

/**
 * Breadcrumb
 */
$vara_page_breadcrumb = vara_inherit_option('general_breadcrumb', 'breadcrumbs_product_visibility', '2');
vara_breadcrumbs($vara_page_breadcrumb, get_theme_mod('breadcrumbs_separator'));

do_action('vara_open_container');
?>
<div class="gs-woo-page large-pt large-pb">
	<div class="<?php echo esc_attr($vara_row_class) ?>">
		<div class="<?php echo esc_attr($vara_product_class) ?>">
			<?php 
			while (have_posts()) {
				the_post();
				wc_get_template_part('content', 'single-product');
			}
			?>
		</div>
		<?php if ($vara_sidebar_option != '3') : ?>
			<div class="<?php echo esc_attr($vara_sidebar_class) ?>">
				<div class="sidebar-container">
					<?php get_sidebar('shop') ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php 
do_action('vara_close_container');

get_template_part('tpls/shop/product/navigation');

get_footer();
