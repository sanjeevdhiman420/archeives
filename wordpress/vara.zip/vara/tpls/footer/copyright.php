<?php
/**
 * Footer Copyright
 */
if (vara_inherit_option('footer_copyright_visibility', 'footer_copyright_visibility', '1') == '2' && !is_search()) {
	return;
}

$vara_footer_copyright = get_theme_mod('footer_copyright');
if (!$vara_footer_copyright && get_theme_mod('footer_copyright_automated', '1') == '1') {
	$vara_footer_copyright = sprintf(
		'%s %s %s. %s',
		'©',
		date('Y'),
		get_bloginfo('name'),
		esc_html__('All rights reserved.', 'vara')
	);
}

// Social Media
$vara_social_media_visibility = vara_inherit_option('footer_social_media_visibility', 'footer_social_media_visibility', '1');
$vara_social_media_enabled = get_theme_mod('footer_social_media_enabled', ['facebook', 'twitter', 'dribbble', 'pinterest', 'linkedin']);

if ($vara_social_media_visibility == '2' && empty($vara_footer_copyright)) {
	return;
}

// Alignment
if (vara_inherit_option('footer_copyright_alignment', 'footer_copyright_alignment', '1') == '1') {
	$vara_footer_row = 'row';
	$vara_copyright_class = 'subfooter-coypright-text';
	$vara_social_media_class = 'social-network-links subfooter-social-network gs-text-right';
} else {
	$vara_footer_row = 'row flex-row-reverse';
	$vara_copyright_class = 'subfooter-coypright-text gs-text-right';
	$vara_social_media_class = 'subfooter-social-network';
}
?>
<div class="subfooter-area">
	<div class="container">
		<div class="subfooter-area-inner">
			<div class="<?php echo esc_attr($vara_footer_row) ?> d-flex align-items-center">
				<div class="col-sm-6">
					<div class="<?php echo esc_attr($vara_copyright_class) ?>">
						<?php echo wpautop(wp_kses_post($vara_footer_copyright)) ?>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="<?php echo esc_attr($vara_social_media_class) ?>">
						<?php vara_social_media($vara_social_media_visibility, $vara_social_media_enabled) ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>