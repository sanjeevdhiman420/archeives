<?php
/**
 * Classic Grid
 *
 * the template will called incase
 * the user has selected meta outside
 * as shop type.
 */
global $product;

$vara_shop_classic_grid_class = ['gs-product-item', 'product-item--classic-grid'];

?>
<div class="<?php echo esc_attr( implode( ' ', $vara_shop_classic_grid_class ) ); ?>">

	<?php if ( $grada_products_meta_thumbnail == 'yes' ) : ?>
        <div class="entry-thumbnail gs-product-thumbnail">
            <?php if ( $grada_products_carousel_height == 'full' ) : ?>
                <?php if (has_post_thumbnail()) : ?>
                    <div class="gs-full-height-img gs-bg-img-style" style="background-image: url(<?php the_post_thumbnail_url() ?>)"></div>
                <?php else : ?>
                    <div class="gs-full-height-img gs-bg-img-style" style="background-image: url(<?php echo esc_url(VARA_THEME_PLACEHOLDER) ?>)"></div>
                <?php endif; ?>
            <?php elseif ( has_post_thumbnail() ) : ?>
                <div class="entry-image-ratio" style="<?php echo esc_attr(vara_thumbnail_calculation($grada_products_thumbnail_resizer)) ?>">
                    <?php
                    /**
                     * Thumbnail Sizes
                     *
                     * It inherits the option via set query var.
                     */
                    if ($grada_products_thumbnail_resizer) {
                        the_post_thumbnail($grada_products_thumbnail_resizer);
                    } else {
                        the_post_thumbnail();
                    }
                    ?>
                </div>
            <?php else : ?>
                <div class="entry-image-ratio" style="padding-bottom: 100%">
                    <?php echo wc_placeholder_img('full'); ?>
                </div>
            <?php endif;?>
            <a href="<?php the_permalink(); ?>" class="product-item-link"></a>
            <span class="entry-thumbnail__overlay"></span>
            <?php
                if (!$product->is_in_stock()) {
                    echo '<div class="gs-product-badge out-of-stock">' . esc_html__('Out of Stock', 'vara') . '</div>';
                } elseif ($product->is_on_sale()) {
                    echo '<div class="gs-product-badge sale">' . esc_html__('Sale!', 'vara') . '</div>';
                }
            ?>
            <div class="entry-thumbnail__button">
                <?php wc_get_template_part('woocommerce/loop/add-to-cart') ?>
            </div>
        </div>
	<?php endif; ?>

    <div class="entry-details">
        <div class="entry-details__inner">
	        <?php if ($grada_products_meta_title == 'yes') : ?>
                <h4 class="entry-details-title"><a href="<?php the_permalink() ?>"><?php echo esc_attr($product->get_title()); ?></a></h4>
	        <?php endif; ?>
            <?php if ($grada_products_meta_categories == 'yes' ) : ?>
                <div class="gs-product-cats">
                    <?php
                        echo wc_get_product_category_list( $product->get_id(), ', ' );
                    ?>
                </div>
            <?php endif; ?>
	        <?php if ($grada_products_meta_price == 'yes') : ?>
                <div class="entry-details-price"><?php wc_get_template_part('woocommerce/loop/price') ?></div>
	        <?php endif; ?>
        </div>
    </div>

</div>
