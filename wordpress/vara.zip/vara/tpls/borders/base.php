<?php
/**
 * Theme Borders
 */
?>
<div class="gs-page-boundary">
	<div class="gs-border-top"></div>
	<div class="gs-border-right"></div>
	<div class="gs-border-bottom"></div>
	<div class="gs-border-left"></div>
</div>