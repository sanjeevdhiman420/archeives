<?php

if ( !is_active_sidebar('off-canvas-sidebar') ) {
    return;
}

/**
 * Off Canvas Sidebar Base
 */
$vara_site_off_canvas_sidebar_class = 'gs-off-canvas-sidebar d-none d-lg-block';

/**
 * Visibility
 */
if (vara_inherit_option('off_canvas_sidebar_visibility', 'off_canvas_sidebar_visibility', '1') == '2') {
	return;
}

/**
 * Mobile
 */
if (get_theme_mod('off_canvas_sidebar_skin', '1') == '1') {
	$vara_site_off_canvas_sidebar_class .= ' dark-skin';
}
?>
<div class="<?php echo esc_attr($vara_site_off_canvas_sidebar_class) ?>">
	<?php get_template_part('tpls/header/off-canvas-sidebar/content') ?>
	<div class="off-canvas-sidebar-overlay"></div>
</div>