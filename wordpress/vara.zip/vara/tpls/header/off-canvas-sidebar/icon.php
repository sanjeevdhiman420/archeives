<?php
/**
 * Off Canvas Sidebar Icon
 */

/**
 * Visibility
 */
if (vara_inherit_option('off_canvas_sidebar_visibility', 'off_canvas_sidebar_visibility', '1') == '2' || !is_active_sidebar('off-canvas-sidebar')) {
	return;
}

/**
 * Mobile
 */
$vara_site_offcanvas_sidebar_class = 'off-canvas-sidebar-trigger d-flex';

?>
<a class="<?php echo esc_attr($vara_site_offcanvas_sidebar_class) ?>" href="#">
	<span class="burger-icon">
		<span></span>
		<span></span>
		<span></span>
	</span>
</a>