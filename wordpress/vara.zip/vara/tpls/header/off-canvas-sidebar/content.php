<?php
/**
 * Off Canvas Sidebar Content
 */
?>
<div class="gs-off-canvas-sidebar-holder">
	<span class="close-button off-canvas-sidebar-close"></span>
	<div class="off-canvas-sidebar-inner">
		<?php
			if (is_active_sidebar('off-canvas-sidebar')) {
				dynamic_sidebar('off-canvas-sidebar');
			}
		?>
	</div>
</div>
