<?php
/**
 * Search Icon
 */

/**
 * Visibility
 */
if (vara_inherit_option('header_search_visibility', 'header_search_visibility', '1') == '2') {
	return;
}

/**
 * Mobile
 */
$vara_site_search_icon_class = '';

if (get_theme_mod('header_search_mobile', '2') == '1') {
	$vara_site_search_icon_class = 'search-button-wrapper d-flex';
} else {
	$vara_site_search_icon_class = 'search-button-wrapper d-none d-lg-flex';
}
?>
<div class="<?php echo esc_attr($vara_site_search_icon_class) ?>">
    <a href="#" class="search-button-trigger">
        <svg width="26" height="26" viewBox="0 0 26 26" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="M11.9167 20.5833C16.7031 20.5833 20.5833 16.7031 20.5833 11.9167C20.5833 7.1302 16.7031 3.25 11.9167 3.25C7.1302 3.25 3.25 7.1302 3.25 11.9167C3.25 16.7031 7.1302 20.5833 11.9167 20.5833Z" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M22.75 22.75L18.0375 18.0375" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </a>
    <span class="close-button search-wrapper-close"></span>
</div>