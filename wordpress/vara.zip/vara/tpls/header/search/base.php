<?php
/**
 * Search Base
 */
$vara_site_search_class = 'gs-fullscreen-search';

/**
 * Visibility
 */
if (vara_inherit_option('header_search_visibility', 'header_search_visibility', '1') == '2') {
	return;
}

/**
 * Mobile
 */
if (get_theme_mod('header_search_mobile', '2') == '2') {
	$vara_site_search_class .= ' d-none d-lg-block';
}
?>
<div class="<?php echo esc_attr($vara_site_search_class) ?>">
	<?php get_template_part('tpls/header/search/content') ?>
</div>