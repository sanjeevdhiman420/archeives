<?php
/**
 * Mini Cart
 */
if (!class_exists('WooCommerce') || vara_inherit_option('shopping_cart_visibility', 'shopping_cart_visibility', '1') == '2') {
	return;
}
global $woocommerce;

/**
 * Mobile
 */
$vara_shopping_cart_class = 'header-shopping-cart';
if (get_theme_mod('shopping_cart_mobile', '2') == '1') {
	$vara_shopping_cart_class = 'header-shopping-cart d-flex';
} else {
	$vara_shopping_cart_class = 'header-shopping-cart d-none d-lg-flex';
}
?>
<div class="<?php echo esc_attr($vara_shopping_cart_class) ?>">
	<a class="header-shopping-cart-icon" href="<?php echo esc_url(wc_get_cart_url()) ?>">
        <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="1" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
        <span class="cart-number"><?php echo sprintf('%d', WC()->cart->cart_contents_count); ?></span>
	</a>
	<div class="dropdown-cart">
		<div class="dropdown-shopping-cart widget_shopping_cart_content"></div>
	</div>
</div>