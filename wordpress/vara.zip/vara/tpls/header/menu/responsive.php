<?php
/**
 * Responsive Menu
 */
?>
<div class="container">
	<div class="gs-site-header-inner d-flex align-items-center">
		<?php get_template_part('tpls/header/logo') ?>
		<div class="ml-auto d-flex align-items-center">
			<div class="site-header-tools d-flex align-items-center">
				<?php get_template_part('tpls/header/search/icon') ?>
				<?php get_template_part('tpls/header/shopping-cart') ?>
			</div>
			<a href="#" class="mobile-header-btn" id="mobile-header-btn">
                <span class="burger-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
			</a>
		</div>
	</div>
	<div class="mobile-navigation">
		<?php
		// Main Menu
		$args = array(
			'theme_location' => 'main-menu',
			'container' => 'nav'
		);

		if (has_nav_menu('main-menu')) {
			wp_nav_menu($args);
		}
		?>
	</div>
</div>