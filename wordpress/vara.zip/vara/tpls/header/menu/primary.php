<?php
/**
 * Primary Menu
 */
?>
<div class="container">
	<div class="d-flex align-items-stretch gs-site-header-inner">
        <div class="d-flex align-items-stretch">
	        <?php get_template_part('tpls/header/logo') ?>
        </div>
		<div class="ml-auto d-flex align-items-stretch">
            <div class="site-header-navigation d-flex align-items-stretch">
				<?php
				// Main Menu
				$args = array(
					'theme_location' => 'main-menu',
					'container' => 'nav',
					'container_class' => 'd-flex menu-navigation-regular',
					'menu_class' => 'menu site-header-menu d-flex align-items-center',
					'fallback_cb'     => 'top_navigation_fallback',
					'walker'          => new GradaClassTopNavigationWalker()
				);

				if (has_nav_menu('main-menu')) {
					wp_nav_menu($args);
				}
				?>
            </div>
			<div class="d-flex align-items-stretch">
				<?php if (vara_inherit_option('sliding_bar_visibility', 'sliding_bar_visibility', '2') == '1' || vara_inherit_option('shopping_cart_visibility', 'shopping_cart_visibility', '1') == '1' || vara_inherit_option('header_search_visibility', 'header_search_visibility', '1') == '1') : ?>
					<div class="site-header-tools d-flex align-items-stretch">
						<?php get_template_part('tpls/header/search/icon') ?>
						<?php get_template_part('tpls/header/shopping-cart') ?>
                        <?php get_template_part('tpls/header/off-canvas-sidebar/icon'); ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>