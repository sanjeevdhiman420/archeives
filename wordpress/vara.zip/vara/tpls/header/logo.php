<?php
/**
 * Default Logo
 */
$vara_logo_display = $vara_light_logo_display = $vara_logo_style = [];

/**
 * Logos
 */
$vara_dark_logo = get_theme_mod('header_dark_logo');
$vara_light_logo = get_theme_mod('header_light_logo');
$vara_text_logo = get_theme_mod('header_logo_text');
$vara_custom_dark_logo = get_field('header_dark_logo');
$vara_custom_light_logo = get_field('header_light_logo');

/**
 * Logo Attributes
 */
$vara_logo_width = get_theme_mod('header_logo_width');
$vara_logo_height = get_theme_mod('header_logo_height');
$vara_logo_custom_width = get_field('header_logo_width');
$vara_logo_custom_height = get_field('header_logo_height');
$vara_logo_text_size = get_theme_mod('header_logo_text_size');

/**
 * Logo Classes & Extensions
 */
$vara_logo_class = 'gs-logo gs-logo-img';
$vara_dark_logo_img_class = 'logo-img-holder logo-default';
$vara_light_logo_img_class = 'logo-img-holder logo-light';
$vara_logo_ext = 'png';

/**
 * Dark Logo
 */
if ($vara_custom_dark_logo) {
	$vara_logo_display = $vara_custom_dark_logo;
} elseif ($vara_custom_light_logo) {
	$vara_logo_display = $vara_custom_light_logo;
} elseif ($vara_dark_logo) {
	$vara_logo_display = $vara_dark_logo;
} elseif ($vara_light_logo) {
	$vara_logo_display = $vara_light_logo;
} else {
	$vara_logo_class = 'gs-logo gs-logo-text';
}

/**
 * Light Logo
 */
if ($vara_custom_light_logo) {
	$vara_light_logo_display = $vara_custom_light_logo;
} elseif ($vara_light_logo) {
	$vara_light_logo_display = $vara_light_logo;
}

/**
 * Logo Attributes
 */
if ($vara_logo_display) {
	if ($vara_logo_custom_width) {
		$vara_logo_style[] = 'width: '. $vara_logo_custom_width .'px';
	} elseif ($vara_logo_width) {
		$vara_logo_style[] = 'width: '. $vara_logo_width .'px';
	} elseif (!strpos(wp_get_attachment_url($vara_logo_display), '.svg')) {
		$vara_logo_style[] = 'width: '. wp_get_attachment_metadata($vara_logo_display)['width'] .'px';
	}

	if ($vara_logo_custom_height) {
		$vara_logo_style[] = 'height: '. $vara_logo_custom_height .'px';
	} elseif ($vara_logo_height) {
		$vara_logo_style[] = 'height: '. $vara_logo_height .'px';
	} elseif (!strpos(wp_get_attachment_url($vara_logo_display), '.svg')) {
		$vara_logo_style[] = 'height: '. wp_get_attachment_metadata($vara_logo_display)['height'] .'px';
	}
}

/**
 * Logo Text Size
 */
if ($vara_logo_text_size && !$vara_logo_display && !$vara_light_logo_display) {
	$vara_logo_style[] = 'font-size: '. $vara_logo_text_size .'px';
}



?>
<div class="<?php echo esc_attr($vara_logo_class) ?>">
	<a href="<?php echo esc_url(home_url('/')); ?>" style="<?php echo esc_attr(implode(';', $vara_logo_style)) ?>">
		<?php
		// Dark Logo
		if ($vara_logo_display) {
			echo wp_get_attachment_image($vara_logo_display, 'full', '', array('class' => $vara_dark_logo_img_class, 'alt' => get_bloginfo('name')));
		} elseif ($vara_text_logo) {
			echo esc_attr($vara_text_logo);
		} else {
			bloginfo('name');
		}

		// Light Logo
		if ($vara_light_logo_display) {
			echo wp_get_attachment_image($vara_light_logo_display, 'full', '', array('class' => $vara_light_logo_img_class, 'alt' => get_bloginfo('name')));
		}
		?>
	</a>
</div>