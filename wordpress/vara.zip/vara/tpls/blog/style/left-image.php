<?php
/**
 * Left Image
 */
$vara_blog_meta_outside_class = ['gs-blog-post', 'gs-blog-post--left-image', 'd-flex', 'align-items-center'];

?>
<div class="<?php echo esc_attr( implode( ' ', $vara_blog_meta_outside_class ) ); ?>">

	<?php if ($grada_posts_meta_thumbnail == 'yes') : ?>
        <div class="entry-thumbnail">
            <a href="<?php the_permalink() ?>" class="entry-thumbnail__link">
				<?php if (has_post_thumbnail()) : ?>
                    <div class="entry-image-ratio" style="<?php echo esc_attr(vara_thumbnail_calculation($grada_posts_thumbnail_resizer)) ?>">
						<?php
						/**
						 * Thumbnail Sizes
						 *
						 * It inherits the option via set query var.
						 */
						if ($grada_posts_thumbnail_resizer) {
							the_post_thumbnail($grada_posts_thumbnail_resizer);
						} else {
							the_post_thumbnail();
						}
						?>
                    </div>
				<?php else: ?>
                    <div class="entry-image-ratio" style="padding-bottom: 100%;">
                        <img src="<?php echo esc_url(VARA_THEME_PLACEHOLDER) ?>" alt="<?php echo esc_attr__('Image Placeholder Image', 'vara'); ?>">
                    </div>
				<?php endif; ?>
            </a>
        </div>
	<?php endif; ?>

    <div class="entry-details">
        <div class="entry-details__inner">

	        <?php if ($grada_posts_meta_date == 'yes' || $grada_posts_meta_categories == 'yes' || $grada_posts_meta_tags == 'yes') : ?>
                <div class="entry-details-meta">
			        <?php
			        /**
			         * Date
			         */
			        $grada_posts_meta_date == 'yes' ? get_template_part('tpls/blog/extra/date') : '';

			        /**
			         * Categories
			         */
			        $grada_posts_meta_categories == 'yes' ? get_template_part('tpls/taxonomy/categories') : '';

			        /**
			         * Tags
			         */
			        $grada_posts_meta_tags == 'yes' ? get_template_part('tpls/taxonomy/tags') : '';
			        ?>
                </div>
	        <?php endif; ?>

	        <?php if ($grada_posts_meta_title == 'yes') : ?>
                <h4 class="entry-details-title">
                    <a href="<?php the_permalink() ?>"><?php the_title() ?></a>
                </h4>
	        <?php endif; ?>

            <?php
                /**
                 * Excerpt
                 */
                $grada_posts_meta_excerpt == 'yes' ? the_excerpt() : '';


            ?>
            <a class="gs-read-more" href="<?php the_permalink() ?>">
                <span class="text"><?php echo esc_html__('Read More', 'vara') ?></span>
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 22 12" style="enable-background:new 0 0 22 12;" xml:space="preserve"><line x1="0.3" y1="6" x2="21.3" y2="6"></line><polyline points="15.8,0.6 21.3,6 15.8,11.4 "></polyline></svg>
            </a>
        </div>
    </div>

</div>
