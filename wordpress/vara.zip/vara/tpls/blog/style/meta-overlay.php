<?php
/**
 * Meta Overlay
 */
$vara_blog_meta_outside_class = ['gs-blog-post', 'gs-blog-post--meta-overlay'];

?>

<div class="<?php echo esc_attr( implode( ' ', $vara_blog_meta_outside_class ) ); ?>">
    <div class="entry-thumbnail">
        <a href="<?php the_permalink() ?>" class="entry-thumbnail__link">
            <?php if (has_post_thumbnail()) : ?>
                <div class="entry-image-ratio" style="<?php echo esc_attr(vara_thumbnail_calculation($grada_posts_thumbnail_resizer)) ?>">
                    <?php
                    /**
                     * Thumbnail Sizes
                     *
                     * It inherits the option via set query var.
                     */
                    if ($grada_posts_thumbnail_resizer) {
                        the_post_thumbnail($grada_posts_thumbnail_resizer);
                    } else {
                        the_post_thumbnail();
                    }
                    ?>
                </div>
            <?php else: ?>
                <div class="entry-image-ratio" style="padding-bottom: 100%;">
                    <img src="<?php echo esc_url(VARA_THEME_PLACEHOLDER) ?>" alt="<?php echo esc_attr__('Image Placeholder Image', 'vara'); ?>">
                </div>
            <?php endif; ?>
        </a>
        <a href="<?php the_permalink(); ?>" class="link-overlay"></a>
        <div class="entry-details">
            <div class="entry-details__inner gs-text-center">



                <?php if ($grada_posts_meta_title == 'yes') : ?>
                    <h4 class="entry-details-title">
                        <a href="<?php the_permalink() ?>"><?php the_title() ?></a>
                    </h4>
                <?php endif; ?>

                <?php if ($grada_posts_meta_date == 'yes' || $grada_posts_meta_categories == 'yes' || $grada_posts_meta_tags == 'yes') : ?>
                    <div class="entry-details-meta">
                        <?php
                        /**
                         * Date
                         */
                        $grada_posts_meta_date == 'yes' ? get_template_part('tpls/blog/extra/date') : '';

                        /**
                         * Categories
                         */
                        $grada_posts_meta_categories == 'yes' ? get_template_part('tpls/taxonomy/categories') : '';

                        /**
                         * Tags
                         */
                        $grada_posts_meta_tags == 'yes' ? get_template_part('tpls/taxonomy/tags') : '';
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>