<?php

/**
 * Type
 */
$vara_blog_type = get_theme_mod('blog_type', 'classic-grid');
$vara_blog_wrapper = ['gs-entries-style-'. $vara_blog_type];

$vara_blog_hover = get_theme_mod( 'blog_hover_visibility', 'none' );
if ( $vara_blog_hover !== 'none' ) {
    $vara_blog_wrapper[] = 'gs-blog-has-hover';
    $vara_blog_wrapper[] = 'gs-blog-hover-' . $vara_blog_hover;
}

/**
 * Columns
 *
 * It changes the columns via the selector
 * item class.
 */
$vara_selector_class = 'iso-item';

switch (get_theme_mod('blog_columns', '2')) {
	case '1':
		$vara_selector_class .= ' col-12';
		break;
	default:
		$vara_selector_class .= ' col-sm-6';
		break;
	case '3':
		$vara_selector_class .= ' col-md-4 col-sm-6';
		break;
	case '4':
		$vara_selector_class .= ' col-md-3 col-sm-6';
		break;
}

/**
 * Sidebar
 *
 * Three different options for sidebar
 * two are for placements on the left
 * and the right and the other one to
 * hide the sidebar.
 */
$vara_row_class = 'row';
$vara_posts_class = 'col-lg-8';
$vara_sidebar_class = 'col-lg-4';

if (get_theme_mod('blog_sidebar', '2') == '1') {
	$vara_row_class .= ' flex-row-reverse';
} elseif (get_theme_mod('blog_sidebar', '2') == '3') {
	$vara_posts_class = 'col-12';
	$vara_sidebar_class = 'gs-d-none';
}

/**
 * Prevent Empty Sidebar
 */
if (!is_active_sidebar('main-sidebar')) {
	$vara_posts_class = 'col-12';
	$vara_sidebar_class = 'gs-d-none';
}

/**
 * Animation & WOW Delay
 */
$vara_blog_animation = get_theme_mod('blog_animation', '2');
$vara_blog_holder_class = 'gs-blog-item';

if ($vara_blog_animation == '2' || $vara_blog_animation == '4') {
	$vara_blog_holder_class .= ' gsFadeIn wow';
} elseif ($vara_blog_animation == '3' || $vara_blog_animation == '5') {
	$vara_blog_holder_class .= ' gsFadeInUp wow';
}

$vara_data_wow_delay = false;
$vara_data_wow_seconds = 0;

if ($vara_blog_animation == '4' || $vara_blog_animation == '5') {
	$vara_data_wow_delay = true;
}

/**
 * Spacing
 *
 * It's used for the spacing between
 * blog posts.
 */
$vara_blog_spacing = get_theme_mod('blog_spacing', '2');
$vara_blog_spacing_value = get_theme_mod('blog_spacing_value', 30);

$vara_blog_spacing_bool = $vara_blog_spacing == '1' && $vara_blog_spacing_value || $vara_blog_spacing == '1' && $vara_blog_spacing_value == '0' ? true : false;
$vara_blog_spacing_row = $vara_blog_spacing_selector = $vara_blog_spacing_post = null;

if ($vara_blog_spacing == '1' && $vara_blog_spacing_value) {
	$vara_blog_spacing_row = 'margin-left: -'. $vara_blog_spacing_value / 2 .'px; margin-right: -'. $vara_blog_spacing_value / 2 .'px';
	$vara_blog_spacing_selector = 'padding-left: '. $vara_blog_spacing_value / 2 .'px; padding-right: '. $vara_blog_spacing_value / 2 .'px';
	$vara_blog_spacing_post = 'margin-bottom: '. $vara_blog_spacing_value .'px';
} elseif ($vara_blog_spacing == '1' && $vara_blog_spacing_value == '0') {
	$vara_blog_spacing_row = 'margin-left: 0; margin-right: 0';
	$vara_blog_spacing_selector = 'padding-left: 0; padding-right: 0';
	$vara_blog_spacing_post = 'margin-bottom: 0';
}

/**
 * Meta Visibility
 */
set_query_var('grada_posts_meta_thumbnail', get_theme_mod('blog_thumbnail_visibility', 'yes'));
set_query_var('grada_posts_meta_title', 'yes');
set_query_var('grada_posts_meta_date', get_theme_mod('blog_date_visibility', 'yes'));
set_query_var('grada_posts_meta_categories', get_theme_mod('blog_categories_visibility', 'yes'));
set_query_var('grada_posts_meta_tags', get_theme_mod('blog_tags_visibility', 'no'));
set_query_var('grada_posts_meta_excerpt', get_theme_mod('blog_excerpt_visibility', 'yes'));
set_query_var('grada_posts_meta_author', get_theme_mod('blog_author_visibility', 'yes'));
set_query_var('grada_posts_style_author_avatar', 'yes');
set_query_var('grada_posts_style_author_alignment', 'left');
set_query_var('grada_posts_carousel_height', 'auto');

/**
 * Hover Animation
 *
 * Pass the variable to global query to
 * inherit later in meta-inside and outside
 * of the blog types.
 */
set_query_var('grada_posts_hover_animation', get_theme_mod('blog_hover_animation', 'translate'));

/**
 * Thumbnail Sizes
 */
$grada_blog_thumbnail_resizer = get_theme_mod('blog_thumbnail_resizer', 'no');
$grada_blog_thumbnail_sizes = get_theme_mod('blog_thumbnail_sizes', 'full');
$grada_blog_thumbnail_resizer_output = null;

if ($grada_blog_thumbnail_resizer == 'yes') {
	$grada_blog_thumbnail_resizer_output = $grada_blog_thumbnail_sizes;
}

set_query_var('grada_posts_thumbnail_resizer', $grada_blog_thumbnail_resizer_output);

/**
 * Paged
 *
 * Tell the WordPress exactly
 * what page is active.
 */
if (get_query_var('paged')) {
	$paged = get_query_var('paged');
} elseif (get_query_var('page')) {
	$paged = get_query_var('page');
} else {
	$paged = 1;
}

// Show more ajax, excluded posts
$exclude = isset($_GET['exclude']) ? $_GET['exclude'] : '';

/**
 * Arguments
 *
 * Modify the query with
 * different arguments properties.
 */
$args = array(
	'post_type' => 'post',
	'paged' => $paged
);

if ($exclude) {
	$args['post__not_in'] = $exclude;
}

if (is_home()) {
	$query = new WP_Query($args);
} else {
	$query = $wp_query;
}

if ($query->have_posts()) : ?>
    <div class="gs-blog-wrapper <?php echo esc_attr( implode( ' ', $vara_blog_wrapper ) ); ?> gs-overflow-hidden large-pt large-pb">
        <div class="container">
            <div class="<?php echo esc_attr($vara_row_class) ?>">
                <div class="<?php echo esc_attr($vara_posts_class) ?>">
                    <div class="gs-blog-holder-inner">
                        <div class="row isotope-container" data-entries-source="<?php echo md5('vara-blog-page') ?>" <?php echo wp_kses_post($vara_blog_spacing_bool ? 'style="'. $vara_blog_spacing_row .'"' : '') ?>>
							<?php while ($query->have_posts()) : $query->the_post() ?>
								<?php
								/**
								 * WOW Animation
								 */
								$vara_data_wow_seconds == 12 ? $vara_data_wow_seconds = 0 : '';
								$vara_wow_holder = "data-wow-delay=". $vara_data_wow_seconds/10 ."s";
								?>
                                <div <?php post_class($vara_selector_class) ?> id="id-<?php the_ID() ?>" data-id="<?php the_ID() ?>" <?php echo wp_kses_post($vara_blog_spacing_bool ? 'style="'. $vara_blog_spacing_selector .'"' : '') ?>>
                                    <div class="<?php echo esc_attr($vara_blog_holder_class) ?>" <?php echo esc_attr($vara_data_wow_delay === true && $vara_data_wow_seconds ? $vara_wow_holder : '') ?> <?php echo wp_kses_post($vara_blog_spacing_bool ? 'style="'. $vara_blog_spacing_post .'"' : '') ?>>
	                                    <?php
	                                    /**
	                                     * Layout Type
	                                     */
	                                    get_template_part('tpls/blog/style/' . $vara_blog_type );
	                                    ?>
                                    </div>
                                </div>
								<?php $vara_data_wow_seconds = $vara_data_wow_seconds + 2; endwhile; ?>
                        </div>
						<?php
						/**
						 * Pagination
						 */
						if (get_theme_mod('blog_pagination_visibility', '1') == '1' || !is_home()) {
							grada_paging_navigation($wp_query);
						}
						?>
                    </div>
                </div>
				<?php if (get_theme_mod('blog_sidebar', '2') !== '3' && is_active_sidebar('main-sidebar')) : ?>
                    <div class="<?php echo esc_attr($vara_sidebar_class) ?>">
                        <div class="sidebar-container archive-sidebar">
							<?php get_sidebar() ?>
                        </div>
                    </div>
				<?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; wp_reset_postdata(); ?>
