<?php 
/**
 * Author of Post in Blog
 */

$grada_posts_author_class = ['entry-meta-author', 'd-flex align-items-center'];

if ($grada_posts_style_author_alignment == 'center') {
    $grada_posts_author_class[] = 'justify-content-center';
} elseif ($grada_posts_style_author_alignment == 'right') {
    $grada_posts_author_class[] = 'justify-content-end';
}
?>
<div class="<?php echo esc_attr(implode(' ', $grada_posts_author_class)) ?>">
    <?php if ($grada_posts_style_author_avatar == 'yes') : ?>
        <div class="avatar">
            <?php echo get_avatar(get_the_author_meta('ID'), 32) ?>
        </div>
    <?php endif; ?>
    <div class="author-name">
        <?php the_author_posts_link() ?>
    </div>
</div>