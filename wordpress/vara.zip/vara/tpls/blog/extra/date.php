<?php 
/**
 * Date of Post in Blog
 */
?>
<span class="entry-meta-date gs-divider">
    <span><?php the_time(get_option('date_format')) ?></span>
</span>