<?php 
/**
 * Taxonomy Hero
 * 
 * It is called on each taxonomy,
 * the options can be set from customizer
 * or in each taxonomy individually.
 */
$vara_hero_class = ['gs-page-heading-bg-img'];
$vara_hero_content_class = ['gs-page-heading-inner', 'align-self-center'];
$vara_hero_style = $vara_hero_height = $vara_hero_title_style = $vara_hero_subtitle_style = [];

/**
 * Queried Object
 */
 if (class_exists('WooCommerce') && is_shop()) {
    $queried_object = wc_get_page_id('shop');
} else if (is_tax() && isset(get_queried_object()->term_id)) {
    $queried_object = 'term_' . get_queried_object()->term_id;
} else {
    $queried_object = get_queried_object();
}

/**
 * Visibility
 */
if (vara_inherit_option('hero_visibility', 'hero_visibility', '2') == '2') {
    return;
}

/**
 * Container
 */
if (vara_inherit_option('hero_container', 'hero_container', '1') == '2') {
    $vara_hero_content_class[] = 'gs-fullwidth-container';
}

/**
 * Alignment
 */
switch (vara_inherit_option('hero_alignment', 'hero_alignment', '2')) {
    case '1':
        $vara_hero_content_class[] = 'gs-text-left';
        break;
    default:
        $vara_hero_content_class[] = 'gs-text-center';
        break;
    case '3':
        $vara_hero_content_class[] = 'gs-text-right';
        break;
}

/**
 * Height
 */
if (get_field('hero_height', $queried_object) == '2' && get_field('hero_custom_height', $queried_object)) {
    $vara_hero_custom_height = get_field('hero_custom_height', $queried_object);
} else {
    $vara_hero_custom_height = get_theme_mod('hero_height', '45vh');
}

if ($vara_hero_custom_height) {
    $vara_hero_height[] = 'height: '. $vara_hero_custom_height .'';
}

/**
 * Image
 */
$vara_hero_image = vara_inherit_option('hero_image', 'hero_image', '1');

// Increase the number for 1, because the taxonomies doesn't have the option use the post/page featured image
if (get_field('hero_image', $queried_object) > 1 && class_exists('WooCommerce') && !is_shop()) {
    $vara_hero_image++;
}

if (class_exists('WooCommerce') && is_shop()) {
    $vara_hero_custom_image = get_field('hero_image', $queried_object) == '3' ? get_field('hero_custom_image', $queried_object) : get_theme_mod('hero_custom_image');
} else {
    $vara_hero_custom_image = get_field('hero_image', $queried_object) == '2' ? get_field('hero_custom_image', $queried_object) : get_theme_mod('hero_custom_image');
}
 
if ($vara_hero_image == '2' && $vara_hero_custom_image) {
    $vara_hero_style[] = 'background-image: url('. wp_get_attachment_url($vara_hero_custom_image) .')';
} else {
    $vara_hero_class[] = 'no-image-background';
}

/**
 * Image Repeat
 */
switch (vara_inherit_option('hero_image_repeat', 'hero_image_repeat', '1')) {
    case '1':
        $vara_hero_style[] = 'background-repeat: no-repeat';
        break;
    case '2':
        $vara_hero_style[] = 'background-repeat: repeat-all';
        break;
    case '3':
        $vara_hero_style[] = 'background-repeat: repeat-x';
        break;
    case '4':
        $vara_hero_style[] = 'background-repeat: repeat-y';
        break;
}

/**
 * Image Attachment
 */
$hero_image_attachment = vara_inherit_option('hero_image_attachment', 'hero_image_attachment', '1');

if ($hero_image_attachment == '2') {
    $vara_hero_style[] = 'background-attachment: fixed';
} elseif ($hero_image_attachment == '3') {
    $vara_hero_style[] = 'background-attachment: local';
}

/**
 * Image Position
 */
switch(vara_inherit_option('hero_image_position', 'hero_image_position', '5')) {
    case '1':
        $vara_hero_style[] = 'background-position: left top';
        break;
    case '2':
        $vara_hero_style[] = 'background-position: left center';
        break;
    case '3':
        $vara_hero_style[] = 'background-position: left bottom';
        break;
    case '4':
        $vara_hero_style[] = 'background-position: center top';
        break;
     case '5':
        $vara_hero_style[] = 'background-position: center center';
        break;
    case '6':
        $vara_hero_style[] = 'background-position: center bottom';
        break;
    case '7':
        $vara_hero_style[] = 'background-position: right top';
        break;
    case '8':
        $vara_hero_style[] = 'background-position: right center';
        break;
    case '9':
        $vara_hero_style[] = 'background-position: right bottom';
        break;
}

/**
 * Image Size
 */
switch(vara_inherit_option('hero_image_size', 'hero_image_size', '2')) {
    case '2':
        $vara_hero_style[] = '-webkit-background-size: cover; -moz-background-size: cover; background-size: cover;';
        break;
    case '3':
        $vara_hero_style[] = '-webkit-background-size: contain; -moz-background-size: contain; background-size: contain;';
        break;
    case '4':
        $vara_hero_style[] = '-webkit-background-size: initial; -moz-background-size: initial; background-size: initial;';
        break;
}

/**
 * Overlay
 */
$vara_hero_image_overlay = vara_inherit_option('hero_image_overlay', 'hero_image_overlay', '2');
$vara_hero_image_overlay_opacity = (get_field('hero_image_overlay', $queried_object) == '2') ? get_field('hero_image_overlay_opacity', $queried_object) : get_theme_mod('hero_image_overlay_opacity');
$vara_hero_image_overlay_color = (get_field('hero_image_overlay', $queried_object) == '2') ? get_field('hero_image_overlay_color', $queried_object) : get_theme_mod('hero_image_overlay_color');
$vara_hero_image_overlay_style = [];

if ($vara_hero_image_overlay == '1') {
    if ($vara_hero_image_overlay_opacity) {
        $vara_hero_image_overlay_style[] = 'opacity: '. $vara_hero_image_overlay_opacity .'';
    }   
    if ($vara_hero_image_overlay_color) {
        $vara_hero_image_overlay_style[] = 'background-color: '. $vara_hero_image_overlay_color .'';
    }     
}

/**
 * Title
 */
$vara_hero_title = vara_inherit_option('hero_title', 'hero_title', '1');
$vara_hero_custom_title = (get_field('hero_title', $queried_object) == '3') ? get_field('hero_custom_title', $queried_object) : get_theme_mod('hero_custom_title');
$vara_hero_title_markup = '';
$vara_hero_title_class = 'gs-page-heading-title';

if (class_exists('WooCommerce') && is_shop()) {
    $vara_hero_title_markup = woocommerce_page_title(false);
} elseif (is_date()) {
    $vara_hero_title_markup = get_the_date();
} elseif (is_author()) {
    $vara_hero_title_markup = get_the_author();
} elseif ($vara_hero_title == '1') {
    $vara_hero_title_markup = single_term_title('', false);
} elseif ($vara_hero_title == '2' && $vara_hero_custom_title) {
    $vara_hero_title_markup = $vara_hero_custom_title;
} 

/**
 * Title Animation
 */
if (vara_inherit_option('hero_title_animation', 'hero_title_animation', '2') == '2') {
    $vara_hero_title_class .= ' gsFadeIn wow';
} elseif (vara_inherit_option('hero_title_animation', 'hero_title_animation', '2') == '3') {
    $vara_hero_title_class .= ' gsFadeInUp wow';
}

/**
 * Title Color
 */
$vara_hero_title_color = get_field('hero_title_color', $queried_object) == '1' ? get_theme_mod('hero_title_color', '#232931') : get_field('hero_title_color_custom', $queried_object);
$vara_hero_title_color && $vara_hero_title_color != '#232931' ? $vara_hero_title_style[] = 'color: '. $vara_hero_title_color .'' : '';

/**
 * Subtitle
 */
$vara_hero_subtitle_class = 'gs-page-heading-description';

if (get_field('hero_subtitle', $queried_object) == '1') {
    $vara_hero_custom_subtitle = get_theme_mod('hero_subtitle');
} else {
    $vara_hero_custom_subtitle = get_field('hero_custom_subtitle', $queried_object);
}

/**
 * Subtitle Animation
 */
if (vara_inherit_option('hero_subtitle_animation', 'hero_subtitle_animation', '2') == '2') {
    $vara_hero_subtitle_class .= ' gsFadeIn wow';
} elseif (vara_inherit_option('hero_subtitle_animation', 'hero_subtitle_animation', '2') == '3') {
    $vara_hero_subtitle_class .= ' gsFadeInUp wow';
}

/**
 * Subtitle Color
 */
$vara_hero_subtitle_color = get_field('hero_subtitle_color', $queried_object) == '1' ? get_theme_mod('hero_subtitle_color', '#858585') : get_field('hero_subtitle_color_custom', $queried_object);
$vara_hero_subtitle_color && $vara_hero_subtitle_color != '#858585' ? $vara_hero_subtitle_style[] = 'color: '. $vara_hero_subtitle_color .'' : '';

/**
 * Output the Hero
 */
echo sprintf(
    '<div class="gs-page-heading-outer d-flex" %s>
        <div class="gs-page-heading-bg">
            <div class="%s" %s></div>
            %s
        </div>
        <div class="%s">
            <div class="container">%s %s</div>
        </div>
    </div>',
    $vara_hero_custom_height ? 'style="'. implode(';', $vara_hero_height) .'"' : '',
    implode(' ', $vara_hero_class),
    $vara_hero_style ? 'style="'. implode(';', $vara_hero_style) .'"' : '',
    $vara_hero_image_overlay == '1' ? '<div class="gs-page-heading-bg-overlay" style="'. implode(';', $vara_hero_image_overlay_style) .'"></div>' : '',
    implode(' ', $vara_hero_content_class),
    $vara_hero_title_markup ? '<div '. ($vara_hero_title_style ? 'style="'. implode(';', $vara_hero_title_style) .'"' : '') . ($vara_hero_title_class ? ' class="'. $vara_hero_title_class .'"' : '') .'>'. $vara_hero_title_markup .'</div>' : '',
    $vara_hero_custom_subtitle ? '<div '. ($vara_hero_subtitle_style ? 'style="'. implode(';', $vara_hero_subtitle_style) .'"' : '') . ($vara_hero_subtitle_class ? ' class="'. $vara_hero_subtitle_class .'"' : '') .'>'. $vara_hero_custom_subtitle .'</div>' : ''
);