<?php 
/**
 * Standard Hero
 * 
 * It is called on each post/page,
 * the options can be set from customizer
 * or in each post/page individually.
 */
$vara_hero_class = ['gs-page-heading-bg-img'];
$vara_hero_content_class = ['gs-page-heading-inner', 'align-self-center'];
$vara_hero_style = $vara_hero_height = $vara_hero_title_style = $vara_hero_subtitle_style = [];

/**
 * Visibility
 */
if (vara_inherit_option('hero_visibility', 'hero_visibility', '2') == '2') {
    return;
}

/**
 * Container
 */
if (vara_inherit_option('hero_container', 'hero_container', '1') == '2') {
    $vara_hero_content_class[] = 'gs-fullwidth-container';
}

/**
 * Alignment
 */
switch (vara_inherit_option('hero_alignment', 'hero_alignment', '2')) {
    case '1':
        $vara_hero_content_class[] = 'gs-text-left';
        break;
    default:
        $vara_hero_content_class[] = 'gs-text-center';
        break;
    case '3':
        $vara_hero_content_class[] = 'gs-text-right';
        break;
}

/**
 * Height
 */
if (get_field('hero_height', get_queried_object()) == '2' && get_field('hero_custom_height', get_queried_object())) {
    $vara_hero_custom_height = get_field('hero_custom_height', get_queried_object());
} else {
    $vara_hero_custom_height = get_theme_mod('hero_height', '45vh');
}

if ($vara_hero_custom_height) {
    $vara_hero_height[] = 'height: '. $vara_hero_custom_height .'';
}

/**
 * Image
 */
$vara_hero_image = vara_inherit_option('hero_image', 'hero_image', '1');
$vara_hero_custom_image = (get_field('hero_image', get_queried_object()) == '3') ? get_field('hero_custom_image', get_queried_object()) : get_theme_mod('hero_custom_image');

if ($vara_hero_image == '1' && has_post_thumbnail()) {
    $vara_hero_style[] = 'background-image: url('. get_the_post_thumbnail_url(get_the_ID(), 'full') .')';
} elseif ($vara_hero_image == '2' && $vara_hero_custom_image) {
    $vara_hero_style[] = 'background-image: url('. wp_get_attachment_url($vara_hero_custom_image) .')';
} else {
    $vara_hero_class[] = 'no-image-background';
}

/**
 * Image Repeat
 */
switch (vara_inherit_option('hero_image_repeat', 'hero_image_repeat', '1')) {
    case '1':
        $vara_hero_style[] = 'background-repeat: no-repeat';
        break;
    case '3':
        $vara_hero_style[] = 'background-repeat: repeat-x';
        break;
    case '4':
        $vara_hero_style[] = 'background-repeat: repeat-y';
        break;
}

/**
 * Image Attachment
 */
$hero_image_attachment = vara_inherit_option('hero_image_attachment', 'hero_image_attachment', '1');

if ($hero_image_attachment == '2') {
    $vara_hero_style[] = 'background-attachment: fixed';
} elseif ($hero_image_attachment == '3') {
    $vara_hero_style[] = 'background-attachment: local';
}

/**
 * Image Position
 */
switch(vara_inherit_option('hero_image_position', 'hero_image_position', '5')) {
    case '1':
        $vara_hero_style[] = 'background-position: left top';
        break;
    case '2':
        $vara_hero_style[] = 'background-position: left center';
        break;
    case '3':
        $vara_hero_style[] = 'background-position: left bottom';
        break;
    case '4':
        $vara_hero_style[] = 'background-position: center top';
        break;
    case '5':
        $vara_hero_style[] = 'background-position: center center';
        break;
    case '6':
        $vara_hero_style[] = 'background-position: center bottom';
        break;
    case '7':
        $vara_hero_style[] = 'background-position: right top';
        break;
    case '8':
        $vara_hero_style[] = 'background-position: right center';
        break;
    case '9':
        $vara_hero_style[] = 'background-position: right bottom';
        break;
}

/**
 * Image Size
 */
switch(vara_inherit_option('hero_image_size', 'hero_image_size', '2')) {
    case '2':
        $vara_hero_style[] = '-webkit-background-size: cover; -moz-background-size: cover; background-size: cover;';
        break;
    case '3':
        $vara_hero_style[] = '-webkit-background-size: contain; -moz-background-size: contain; background-size: contain;';
        break;
    case '4':
        $vara_hero_style[] = '-webkit-background-size: initial; -moz-background-size: initial; background-size: initial;';
        break;
}

/**
 * Overlay
 */
$vara_hero_image_overlay = vara_inherit_option('hero_image_overlay', 'hero_image_overlay', '2');
$vara_hero_image_overlay_opacity = (get_field('hero_image_overlay', get_queried_object()) == '2') ? get_field('hero_image_overlay_opacity', get_queried_object()) : get_theme_mod('hero_image_overlay_opacity');
$vara_hero_image_overlay_color = (get_field('hero_image_overlay', get_queried_object()) == '2') ? get_field('hero_image_overlay_color', get_queried_object()) : get_theme_mod('hero_image_overlay_color');
$vara_hero_image_overlay_style = [];

if ($vara_hero_image_overlay == '1') {
    if ($vara_hero_image_overlay_opacity) {
        $vara_hero_image_overlay_style[] = 'opacity: '. $vara_hero_image_overlay_opacity .'';
    }   
    if ($vara_hero_image_overlay_color) {
        $vara_hero_image_overlay_style[] = 'background-color: '. $vara_hero_image_overlay_color .'';
    }     
}

/**
 * Title
 */
$vara_hero_title = vara_inherit_option('hero_title', 'hero_title', '1');
$vara_hero_custom_title = (get_field('hero_title', get_queried_object()) == '3') ? get_field('hero_custom_title', get_queried_object()) : get_theme_mod('hero_custom_title');
$vara_hero_title_markup = '';
$vara_hero_title_class = 'gs-page-heading-title';

if ($vara_hero_title == '1') {
    $vara_hero_title_markup = get_the_title();
} elseif ($vara_hero_title == '2' && $vara_hero_custom_title) {
    $vara_hero_title_markup = $vara_hero_custom_title;
} 

/**
 * Modify Title in Home
 */
if (is_home()) {
    $vara_hero_title_markup = get_bloginfo('name');
}

/**
 * Title Animation
 */
if (vara_inherit_option('hero_title_animation', 'hero_title_animation', '2') == '2') {
    $vara_hero_title_class .= ' gsFadeIn wow';
} elseif (vara_inherit_option('hero_title_animation', 'hero_title_animation', '2') == '3') {
    $vara_hero_title_class .= ' gsFadeInUp wow';
}

/**
 * Title Color
 */
$vara_hero_title_color = get_field('hero_title_color', get_queried_object()) == '1' ? get_theme_mod('hero_title_color', '#232931') : get_field('hero_title_color_custom');
$vara_hero_title_color && $vara_hero_title_color != '#232931' ? $vara_hero_title_style[] = 'color: '. $vara_hero_title_color .'' : '';

/**
 * Subtitle
 */
$vara_hero_subtitle_class = 'gs-page-heading-description';

if (get_field('hero_subtitle', get_queried_object()) == '1') {
    $vara_hero_custom_subtitle = get_theme_mod('hero_subtitle');
} elseif (get_field('hero_subtitle', get_queried_object()) == '2') {
    $vara_hero_custom_subtitle = vara_breadcrumbs('1', get_theme_mod('breadcrumbs_separator'), true );
} else {
    $vara_hero_custom_subtitle = get_field('hero_custom_subtitle', get_queried_object());
}

/**
 * Subtitle Animation
 */
if (vara_inherit_option('hero_subtitle_animation', 'hero_subtitle_animation', '2') == '2') {
    $vara_hero_subtitle_class .= ' gsFadeIn wow';
} elseif (vara_inherit_option('hero_subtitle_animation', 'hero_subtitle_animation', '2') == '3') {
    $vara_hero_subtitle_class .= ' gsFadeInUp wow';
}

/**
 * Subtitle Color
 */
$vara_hero_subtitle_color = get_field('hero_subtitle_color', get_queried_object()) == '1' ? get_theme_mod('hero_subtitle_color', '#858585') : get_field('hero_subtitle_color_custom');
$vara_hero_subtitle_color && $vara_hero_subtitle_color != '#858585' ? $vara_hero_subtitle_style[] = 'color: '. $vara_hero_subtitle_color .'' : '';

/**
 * Type
 */
$vara_hero_type = vara_inherit_option('hero_type', 'hero_type', '1');
$vara_hero_template = '';
if (get_field('hero_type') == '1') {
    $vara_hero_template = get_theme_mod('hero_template');
} elseif (get_field('hero_type') == '3' && get_field('hero_template')) {
    $vara_hero_template = get_field('hero_template');
}

/**
 * Output the Hero
 */
if ($vara_hero_type == '1') {
    echo sprintf(
        '<div class="gs-page-heading-outer d-flex" %s>
            <div class="gs-page-heading-bg">
                <div class="%s" %s></div>
                %s
            </div>
            <div class="%s">
                <div class="container">%s %s</div>
            </div>
        </div>',
        $vara_hero_custom_height ? 'style="'. implode(';', $vara_hero_height) .'"' : '',
        implode(' ', $vara_hero_class),
        $vara_hero_style ? 'style="'. implode(';', $vara_hero_style) .'"' : '',
        $vara_hero_image_overlay == '1' ? '<div class="gs-page-heading-bg-overlay" style="'. implode(';', $vara_hero_image_overlay_style) .'"></div>' : '',
        implode(' ', $vara_hero_content_class),
        $vara_hero_title_markup ? '<div '. ($vara_hero_title_style ? 'style="'. implode(';', $vara_hero_title_style) .'"' : '') . ($vara_hero_title_class ? ' class="'. $vara_hero_title_class .'"' : '') .'>'. $vara_hero_title_markup .'</div>' : '',
        $vara_hero_custom_subtitle ? '<div '. ($vara_hero_subtitle_style ? 'style="'. implode(';', $vara_hero_subtitle_style) .'"' : '') . ($vara_hero_subtitle_class ? ' class="'. $vara_hero_subtitle_class .'"' : '') .'>'. $vara_hero_custom_subtitle .'</div>' : ''
    );
} elseif ($vara_hero_type == '2' && $vara_hero_template) {
    echo vara_get_custom_template($vara_hero_template);
}