<?php
/**
 * Blog Post
 */
if (vara_inherit_option('blog_post_navigation_visibility', 'blog_post_navigation_visibility', '1') == '2') {
	return;
}

// Navigation Category
if (vara_inherit_option('blog_post_navigation_category', 'blog_post_navigation_category', '2') == '1') {
	$vara_blog_post_navigation = true;
} else {
	$vara_blog_post_navigation = false;
}

if (!get_next_post($vara_blog_post_navigation) && !get_previous_post($vara_blog_post_navigation)) {
	return;
}

// Back URL
$vara_blog_post_navigation_back_url_link = '';
if (get_theme_mod('blog_post_navigation_back_url', '1') == '1' || get_option('page_for_posts')) {
	$vara_blog_post_navigation_nav_cols = 'col-5 col-md-5';
	$vara_blog_post_navigation_url_cols = 'col-2 col-md-2';

	// Link
	$vara_blog_post_navigation_back_url_link = get_theme_mod('blog_post_navigation_back_url_link') ? get_theme_mod('blog_post_navigation_back_url_link') : get_permalink(get_option('page_for_posts'));
} else {
	$vara_blog_post_navigation_nav_cols = 'col-6';
}
?>
<div class="gs-post-nav">
		<div class="row d-flex align-items-center">
			<div class="<?php echo esc_attr($vara_blog_post_navigation_nav_cols) ?> post-nav-link prev">
				<?php previous_post_link('%link', '<div class="d-flex align-items-center"><div class="gs-post-nav-text"><h6 class="gs-post-nav-title">'. esc_html__('Previous Entry', 'vara') .'</h6><h6 class="gs-post-nav-subtitle">%title</h6></div></div>', $vara_blog_post_navigation, '', 'category'); ?>
			</div>
			<?php if (get_theme_mod('blog_post_navigation_back_url', '1') == '1' || get_option('page_for_posts')) : ?>
				<div class="<?php echo esc_attr($vara_blog_post_navigation_url_cols) ?> post-nav-link post-nav-go-back">
                    <div class="d-flex align-items-center justify-content-center">
                        <a href="<?php echo esc_url($vara_blog_post_navigation_back_url_link) ?>">
                            <svg enable-background="new 0 0 270 270" viewBox="0 0 270 270" xmlns="http://www.w3.org/2000/svg" width="20" height="20"><path d="m114 0h-104c-5.5 0-10 4.5-10 10v104c0 5.5 4.5 10 10 10h104c5.5 0 10-4.5 10-10v-104c0-5.5-4.5-10-10-10zm-10 104h-84v-84h84z"/><path d="m260 0h-104c-5.5 0-10 4.5-10 10v104c0 5.5 4.5 10 10 10h104c5.5 0 10-4.5 10-10v-104c0-5.5-4.5-10-10-10zm-10 104h-84v-84h84z"/><path d="m114 146h-104c-5.5 0-10 4.5-10 10v104c0 5.5 4.5 10 10 10h104c5.5 0 10-4.5 10-10v-104c0-5.5-4.5-10-10-10zm-10 104h-84v-84h84z"/><path d="m260 146h-104c-5.5 0-10 4.5-10 10v104c0 5.5 4.5 10 10 10h104c5.5 0 10-4.5 10-10v-104c0-5.5-4.5-10-10-10zm-10 104h-84v-84h84z"/></svg>
                        </a>
                    </div>
				</div>
			<?php endif; ?>
			<div class="<?php echo esc_attr($vara_blog_post_navigation_nav_cols) ?> post-nav-link next gs-text-right">
				<?php next_post_link('%link', '<div class="d-flex align-items-center"><div class="gs-post-nav-text"><h6 class="gs-post-nav-title">'. esc_html__('Next Entry', 'vara') .'</h6><h6 class="gs-post-nav-subtitle">%title</h6></div></div>', $vara_blog_post_navigation, '', 'category'); ?>
			</div>
		</div>
</div>