<?php
/**
 * Meta Overlay
 */
$vara_portfolio_meta_outside_class = ['gs-portfolio-item', 'gs-portfolio-item--meta-overlay'];
$vara_portfolio_content_holder_class = ['entry-details', 'd-flex'];

/**
 * Hover Active
 */
$grada_portfolio_style_hover_active == 'yes' ? $vara_portfolio_meta_outside_class[] = 'hover-active' : '';

/**
 * Content Vertical Alignment
 */
$vara_portfolio_content_holder_class[] = $grada_portfolio_style_hover_meta_vertical_alignment ? 'align-items-'. $grada_portfolio_style_hover_meta_vertical_alignment .'' : 'align-items-center';

/**
 * Hover Style
 */
$vara_portfolio_meta_outside_class[] = 'hover-from-'. $grada_portfolio_style_hover_type;
?>
<div class="<?php echo esc_attr( implode( ' ', $vara_portfolio_meta_outside_class ) ); ?>">
	<div class="entry-overlay-wrapper">
		<div class="entry-thumbnail">
			<a href="<?php the_permalink() ?>" class="entry-thumbnail__link">
				<?php if ($grada_portfolio_carousel_height == 'full') : ?>
					<?php if (has_post_thumbnail()) : ?>
						<div class="gs-full-height-img gs-bg-img-style" style="background-image: url(<?php the_post_thumbnail_url() ?>)"></div>
					<?php else : ?>
						<div class="gs-full-height-img gs-bg-img-style" style="background-image: url(<?php echo esc_url(VARA_THEME_PLACEHOLDER) ?>)"></div>
					<?php endif; ?>
				<?php elseif (has_post_thumbnail()) : ?>
					<div class="entry-image-ratio" style="<?php echo esc_attr(vara_thumbnail_calculation($grada_portfolio_thumbnail_resizer)) ?>">
						<?php
						/**
						 * Thumbnail Sizes
						 *
						 * It inherits the option via set query var.
						 */
						if ($grada_portfolio_thumbnail_resizer) {
							the_post_thumbnail($grada_portfolio_thumbnail_resizer);
						} else {
							the_post_thumbnail();
						}
						?>
					</div>
				<?php else: ?>
					<div class="entry-image-ratio" style="padding-bottom: 100%;">
						<img src="<?php echo esc_url(VARA_THEME_PLACEHOLDER) ?>" alt="<?php echo esc_attr__('Image Placeholder Image', 'vara'); ?>">
					</div>
				<?php endif; ?>
			</a>
		</div>
        <?php if ( $grada_portfolio_hover_visibility == 'show' ) : ?>
            <span class="entry-thumbnail__overlay"></span>
            <div class="<?php echo esc_attr( implode(' ', $vara_portfolio_content_holder_class)); ?>">
                <div class="entry-details__inner">
                    <div class="portfolio-info">
                        <?php if ($grada_portfolio_meta_categories == 'yes' ) : ?>
                            <div class="entry-details-meta">
                                <?php
                                /**
                                 * Categories
                                 */
                                $grada_portfolio_meta_categories == 'yes' ? get_template_part('tpls/taxonomy/categories-portfolio') : '';
                                ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($grada_portfolio_meta_title == 'yes') : ?>
                            <h4 class="entry-details-title">
                                <a href="<?php the_permalink() ?>"><?php the_title() ?></a>
                            </h4>
                        <?php endif; ?>
                    </div>
                </div>
                <a href="<?php the_permalink() ?>"></a>
            </div>
        <?php endif; ?>
	</div>
</div>
