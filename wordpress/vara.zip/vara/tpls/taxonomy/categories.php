<?php
/**
 * Categories
 */
if (!get_the_category()) {
	return;
}
?>
<div class="entry-meta-category gs-divider">
	<ul>
		<?php foreach (get_the_category() as $category) : ?>
			<li><a href="<?php echo esc_url(get_category_link($category->term_id)) ?>"><?php echo esc_attr($category->name) ?></a></li>
		<?php endforeach; ?>
	</ul>
</div>
