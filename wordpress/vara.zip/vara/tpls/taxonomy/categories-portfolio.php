<?php
/**
 * Portfolio Categories 
 */
$portfolio_categories = get_the_terms(get_the_ID(), 'project_cat');

if (!$portfolio_categories) {
    return;
}
?>
<div class="entry-meta-categories gs-divider">
    <ul>
        <?php foreach ($portfolio_categories as $category) : ?>
            <li><a href="<?php echo esc_url(get_category_link($category->term_id)) ?>"><?php echo esc_attr($category->name) ?></a></li>
        <?php endforeach; ?>
    </ul>
</div>