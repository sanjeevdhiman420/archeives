<?php
/**
 * Tags Cloud
 */
if (!get_the_tags()) {
	return;
}
?>
<div class="gs-blog-post-tags">
	<div class="tagcloud">
		<?php foreach (get_the_tags() as $tag) : ?>
			<a href="<?php echo esc_url(get_tag_link($tag->term_id)) ?>"><?php echo esc_attr($tag->name) ?></a>
		<?php endforeach; ?>
	</div>
</div>