<?php
/**
 * Share
 */
if (function_exists('grada_share_social_media')) {
	grada_share_social_media();
} else {
	echo sprintf(
		'<i>%s</i>',
		esc_html__('The plugin Realite Plugin share is not activated, please activate it and try it again. The plugin can be found in includes > plugins.', 'vara')
	);
}