<?php
/**
 * To Top
 *
 * Show the to top button
 * at the bottom of footer.
 */
$vara_to_top_class = ['scrollto-top'];
$vara_to_top_visibility = vara_inherit_option('to_top_visibility', 'to_top_visibility', '1');

if ( $vara_to_top_visibility == '2') {
	return;
}

/**
 * Skin
 */
if (get_theme_mod('to_top_skin', '1') == '1') {
	$vara_to_top_class[] = 'gotop-dark';
} else {
	$vara_to_top_class[] = 'gotop-light';
}

/**
 * animation
 */
if (get_theme_mod('to_top_animation', '1') == '1') {
	$vara_to_top_class[] = 'scrollto-top--translate';
} else {
	$vara_to_top_class[] = 'gotop-zoom';
}
?>
<a href="#" class="<?php echo esc_attr(implode(' ', $vara_to_top_class)) ?>">
    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="1" fill="none" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
</a>