<?php

// Social Media
$vara_social_media_visibility = vara_inherit_option('fixed_social_media_visibility', 'fixed_social_media_visibility', '1');
$vara_social_media_enabled = get_theme_mod('fixed_social_media_enabled', ['facebook', 'twitter', 'vimeo', 'linkedin']);

?>
<div class="gs-social-media-fixed">
	<?php vara_social_media($vara_social_media_visibility, $vara_social_media_enabled) ?>
</div>
