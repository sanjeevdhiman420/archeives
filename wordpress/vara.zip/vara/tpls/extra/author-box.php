<?php
/**
 * Author Box
 */
if (vara_inherit_option('blog_post_author_box', 'blog_post_author', '2') == '2') {
	return;
}

$author = [
	'name' => get_the_author_meta('display_name', $post->post_author),
	'description' => get_the_author_meta('description', $post->post_author),
	'url' => get_author_posts_url($post->post_author)
];

if (get_theme_mod('blog_post_author_archive_button', '1')) {
	$author['archive'] = get_theme_mod('blog_post_author_archive_text', esc_html__('All Author Posts', 'vara'));
}
?>
<div class="gs-author-bio d-flex align-items-center">
	<?php if (get_theme_mod('blog_post_author_avatar', '1') == '1') : ?>
		<div class="gs-author-img">
			<?php echo get_avatar(get_the_author_meta('ID'), 140) ?>
		</div>
	<?php endif; ?>
	<div class="gs-author-bio-details">
		<?php if (get_theme_mod('blog_post_author_name', '1') == '1') : ?>
			<h4 class="gs-author-bio-name"><?php esc_html_e('Written by: ', 'vara' ); ?><a href="<?php echo esc_attr($author['url']) ?>"><?php echo esc_attr($author['name']) ?></a></h4>
		<?php endif; ?>
		<?php if (get_theme_mod('blog_post_author_description', '1') == '1') : ?>
			<p class="gs-author-bio-text">
				<?php echo wp_kses_post($author['description']) ?>
			</p>
		<?php endif; ?>
		<?php if (get_theme_mod('blog_post_author_archive_button', '1') == '1') : ?>
			<a class="gs-btn gs-btn-regular gs-btn-dark d-inline-block" href="<?php echo esc_attr($author['url']) ?>"><?php echo esc_attr($author['archive']) ?></a>
		<?php endif; ?>
	</div>
</div>