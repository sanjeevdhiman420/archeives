<?php 
/**
 * Side Portfolio
 */
$vara_row_class = 'row';
$vara_item_class = 'col-sm-6 col-lg-4';
$vara_gallery_class = 'col-sm-6 col-lg-8';

/**
 * Description Alignment
 * 
 * The alignment of side portfolio moves the
 * description in left or right.
 */
if (get_field('side_portfolio_description_alignment') == '2') {
    $vara_row_class .= ' flex-row-reverse';
} 

/**
 * Description Width
 * 
 * Manipulates with description width, it 
 * changes the columns via a condition.
 */
if (get_field('side_portfolio_description_width') == '1') {
    $vara_item_class = $vara_gallery_class = 'col-sm-6 col-lg-6';
} elseif (get_field('side_portfolio_description_width') == '3') {
    $vara_item_class = 'col-sm-5 col-lg-3';
    $vara_gallery_class = 'col-sm-7 col-lg-9';
}

/**
 * Description Sticky
 * 
 * Makes description sticky on scrolling.
 */
if (get_field('side_portfolio_description_sticky')) {
    $vara_row_class .= ' gs-portfolio-content-sticky';
}
?>
<div class="<?php echo esc_attr($vara_row_class) ?>">
    <div class="gs-portfolio-content-outer <?php echo esc_attr($vara_item_class) ?>">
        <div class="gs-portfolio-content-inner">
            <div class="gs-portfolio-content-top">
                <?php
                /**
                 * Portfolio Item Title
                 */
                if (vara_inherit_option('general_title', 'general_title_portfolio_item', '1') == '1') {
                    the_title('<h2 class="portfolio-single-title">', '</h2>');
                }
                ?>
                <?php if (get_field('portfolio_item_subtitle')) : ?>
                    <h5 class="portfolio-single-subtitle"><?php echo wp_kses_post(get_field('portfolio_item_subtitle')) ?></h5>
                <?php endif; ?>
            </div>
            <div class="gs-portfolio-content-body">
                <?php the_content() ?>
            </div>
            <?php 
            /**
             * Tabs
             */
            get_template_part('tpls/portfolio-item/tabs');

            /**
             * Share
             */
            if (get_theme_mod('portfolio_item_share', '2') == '1') {
                get_template_part('tpls/extra/share');
            }
            ?>
        </div>
    </div>
    <div class="<?php echo esc_attr($vara_gallery_class) ?>">
        <?php get_template_part('tpls/portfolio-item/gallery') ?>
    </div>
</div>