<?php 
/**
 * Vertical Portfolio
 */
$vara_row_class = 'row';
$vara_item_class = 'col-12';
$vara_gallery_class = 'col-12';

/**
 * Description Place
 * 
 * Change the order of description to
 * above or below the gallery.
 */
if (get_field('vertical_portfolio_description_place') == '2') {
    $vara_row_class .= ' d-flex flex-column-reverse';
}

/**
 * Description Width
 * 
 * Change the width of description
 * in relation with tabs.
 */
$vara_item_content_class = 'col-12';
$vara_item_tabs_class = 'gs-d-none';

if (get_field('vertical_portfolio_description_width') == '2') {
    $vara_item_content_class = $vara_item_tabs_class = 'col-sm-6';
} elseif (get_field('vertical_portfolio_description_width') == '3') {
    $vara_item_content_class = 'col-lg-8';
    $vara_item_tabs_class = 'col-lg-4';
}
?>
<div class="<?php echo esc_attr($vara_row_class) ?>">
    <div class="<?php echo esc_attr($vara_item_class) ?>">
        <div class="gs-portfolio-content-top">
            <?php the_title('<h2 class="portfolio-single-title">', '</h2>') ?>
            <?php if (get_field('portfolio_item_subtitle')) : ?>
                <h5 class="portfolio-single-subtitle"><?php echo wp_kses_post(get_field('portfolio_item_subtitle')) ?></h5>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="gs-portfolio-content-outer <?php echo esc_attr($vara_item_content_class) ?>">
                <div class="gs-portfolio-content-inner">
                    <div class="gs-portfolio-content-body">
                        <?php the_content() ?>
                    </div>
                    <?php get_field('vertical_portfolio_description_width') == '1' ? get_template_part('tpls/portfolio-item/tabs') : ''; ?>
                    <?php 
                    if (get_theme_mod('portfolio_item_share', '2') == '1') {
                        get_template_part('tpls/extra/share');
                    }
                    ?>
                </div>
            </div>
            <?php if (get_field('vertical_portfolio_description_width') != '1') : ?>
                <div class="<?php echo esc_attr($vara_item_tabs_class) ?>">
                    <?php get_template_part('tpls/portfolio-item/tabs') ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
     <div class="<?php echo esc_attr($vara_gallery_class) ?>">
        <?php get_template_part('tpls/portfolio-item/gallery') ?>
    </div>
</div>