<?php
/**
 * Portfolio Item Gallery
 */

/**
 * Columns
 *
 * Change gallery items columns
 * via customizer or individually.
 */
switch (vara_inherit_option('portfolio_item_gallery_columns', 'portfolio_item_gallery_columns', '1')) {
	default:
		$vara_gallery_item_column = 'col-12';
		break;
	case '2':
		$vara_gallery_item_column = 'col-sm-6';
		break;
	case '3':
		$vara_gallery_item_column = 'col-sm-6 col-md-4';
		break;
	case '4':
		$vara_gallery_item_column = 'col-sm-6 col-md-3';
		break;
}

/**
 * Animation & WOW Delay
 */
$vara_portfolio_item_gallery_animation = vara_inherit_option('portfolio_item_gallery_animation', 'portfolio_item_gallery_animation', '2');
$vara_portfolio_item_holder_class = 'gs-portfolo-media-item';

if ($vara_portfolio_item_gallery_animation == '2' || $vara_portfolio_item_gallery_animation == '4') {
	$vara_portfolio_item_holder_class .= ' gsFadeIn wow';
} elseif ($vara_portfolio_item_gallery_animation == '3' || $vara_portfolio_item_gallery_animation == '5') {
	$vara_portfolio_item_holder_class .= ' gsFadeInUp wow';
}

$vara_data_wow_delay = false;
$vara_data_wow_seconds = 0;

if ($vara_portfolio_item_gallery_animation == '4' || $vara_portfolio_item_gallery_animation == '5') {
	$vara_data_wow_delay = true;
}

if (have_rows('portfolio_item_gallery')) :
	?>
	<div class="gs-portfolio-media">
		<div class="row isotope-container">
			<?php while (have_rows('portfolio_item_gallery')) : the_row(); ?>
				<?php
				/**
				 * WOW Animation
				 */
				$vara_data_wow_seconds == 12 ? $vara_data_wow_seconds = 0 : '';
				$vara_wow_holder = "data-wow-delay=". $vara_data_wow_seconds/10 ."s";
				?>
				<div class="iso-item <?php echo esc_attr($vara_gallery_item_column) ?>">
					<div class="gs-popup <?php echo esc_attr($vara_portfolio_item_holder_class) ?>" <?php echo esc_attr($vara_data_wow_delay === true && $vara_data_wow_seconds ? $vara_wow_holder : '') ?>>
						<?php if (get_row_layout() == 'portfolio_item_gallery_image') : ?>
							<a class="entry-image-ratio gs-popup-link" data-mfp-src="<?php echo esc_url(get_sub_field('portfolio_item_gallery_image_obj')['url']) ?>" style="<?php echo esc_attr(vara_image_calculation(get_sub_field('portfolio_item_gallery_image_obj')['id'])) ?>">
								<img src="<?php echo esc_url(get_sub_field('portfolio_item_gallery_image_obj')['url']) ?>" alt="<?php echo esc_attr(get_sub_field('portfolio_item_gallery_image_obj')['alt']) ?>">
							</a>
							<?php if ( !empty(get_sub_field('portfolio_item_gallery_image_obj')['caption'])) : ?>
                                <p class="wp-caption"><?php echo wp_kses_post(get_sub_field('portfolio_item_gallery_image_obj')['caption']); ?></p>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
				<?php $vara_data_wow_seconds = $vara_data_wow_seconds + 2; endwhile; ?>
		</div>
	</div>
<?php
endif;