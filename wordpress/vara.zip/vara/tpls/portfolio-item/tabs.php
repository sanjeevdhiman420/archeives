<?php
/**
 * Portfolio Item Tabs
 */
if (!have_rows('portfolio_item_custom_tabs')) {
	return;
}
?>
<div class="gs-portfolio-single-info">
	<ul>
		<?php
		while (have_rows('portfolio_item_custom_tabs')) : the_row();
			?>
			<li>
                <?php if ( !empty( get_sub_field('portfolio_item_custom_tabs_title') ) ) : ?>
				    <h5 class="gs-portfolio-single-info-label"><?php echo esc_attr(get_sub_field('portfolio_item_custom_tabs_title')); ?></h5>
                <?php endif; ?>
				<?php if (get_sub_field('portfolio_item_custom_tabs_type') == '1') : ?>
					<p><?php echo wp_kses_post(get_sub_field('portfolio_item_custom_tabs_description')) ?></p>
				<?php else : ?>
					<a class="gs-btn gs-btn-regular gs-btn-dark d-inline-block" target="<?php echo esc_attr(get_sub_field('portfolio_item_custom_tabs_link_url') ? '_BLANK' : '_SELF') ?>" href="<?php echo esc_url(get_sub_field('portfolio_item_custom_tabs_link_url')) ?>"><?php echo esc_attr(get_sub_field('portfolio_item_custom_tabs_link_title')) ?></a>
				<?php endif; ?>
			</li>
		<?php
		endwhile;
		?>
	</ul>
</div>