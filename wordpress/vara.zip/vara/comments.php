<?php
/**
 * The template file for displaying the comments and comment form for the
 * Realite theme.
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
*/
if ( post_password_required() ) {
	return;
}

$vara_comments_args = array(
	'style'        => 'div',
	'callback'     => 'vara_comments_open',
	'end-callback' => 'vara_comments_close',
);

$vara_comment_form =  array(
	'logged_in_as' => null,
	'comment_notes_before' => null,
	'title_reply_before' => '<h4 id="reply-title" class="gs-comments-title d-flex align-items-end">',
	'title_reply_after' => '</h4>',
	'title_reply' => esc_attr__('Leave a Reply', 'vara'),
	'submit_button' => '<div class="gs-comment-form-submit d-flex"><input name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" /></div>',
	'comment_field' => "<div class='textarea-holder row'><div class='col-12'><textarea placeholder=". esc_attr__('Comment', 'vara') ." type='text' name='comment' aria-required='true'/></textarea></div></div>",
	'fields' => apply_filters('comment_form_default_fields', array(
			'author' => "<div class='input-holder row'><div class='col-sm-4'><input placeholder=". esc_attr__('Name', 'vara') ." name='author' type='text' aria-required='true'/></div>",
			'email' => "<div class='col-sm-4'><input placeholder=". esc_attr__('Email', 'vara') ." name='email' type='text' aria-required='true'/></div>",
			'website' => "<div class='col-sm-4'><input placeholder=". esc_attr__('Website', 'vara') ." name='website' type='text'/></div></div>",
		)
	),
);

 if ( comments_open() || get_comments_number() ) :
	?>
	<div class="gs-post-comments-wrapper">
		<div class="container large-pb">
			<div class="gs-comments" id="comments">

                <?php if ( get_comments_number() ) : ?>
                    <div class="gs-comments-list">
                        <?php
                        $comments_number = absint( get_comments_number() );
                        ?>

                        <h4 class="gs-comments-title">
                            <?php
                                if ( 1 === $comments_number ) {
                                    /* translators: %s: Post title. */
                                    printf( _x( 'One reply on &ldquo;%s&rdquo;', 'comments title', 'vara' ), get_the_title() );
                                } else {
                                    printf(
                                        /* translators: 1: Number of comments, 2: Post title. */
                                        _nx(
                                            '%1$s reply on &ldquo;%2$s&rdquo;',
                                            '%1$s replies on &ldquo;%2$s&rdquo;',
                                            $comments_number,
                                            'comments title',
                                            'vara'
                                        ),
                                        number_format_i18n( $comments_number ),
                                        get_the_title()
                                    );
                                }
                            ?>
                        </h4>
                        <div class="row">
                            <?php wp_list_comments($vara_comments_args) ?>
                        </div>
                        <?php paginate_comments_links(); ?>
                    </div>
                <?php endif; ?>
                <?php if (comments_open() || pings_open()) : ?>
					<div class="gs-comment-form">
						<?php comment_form($vara_comment_form); ?>
					</div>
				<?php elseif (!comments_open() && get_theme_mod('comments_closed', '1') !== '2') : ?>
					<div class="gs-comment-closed">
						<h4 class="gs-comment-closed-title"><?php echo esc_attr__('Comments are closed!', 'vara') ?></h4>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php
endif;

