<?php
/**
 * Blog Single
 */
get_header();

get_template_part('tpls/hero/standard');

/**
 * Sidebar
 */
$vara_row_class = 'row';
$vara_posts_class = 'col-lg-8';
$vara_sidebar_class = 'col-lg-4';

if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '1') {
	$vara_row_class .= ' flex-row-reverse';
} elseif (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '3') {
	$vara_posts_class = 'col-12';
	$vara_sidebar_class = 'gs-d-none';
}

/**
 * Prevent Empty Sidebar
 */
if (!is_active_sidebar('main-sidebar')) {
	$vara_posts_class = 'col-12';
	$vara_sidebar_class = 'gs-d-none';
}


if ( have_posts() ) : while ( have_posts() ) : the_post();

	/**
	 * Breadcrumb
	 */
	$vara_page_breadcrumb = vara_inherit_option('general_breadcrumb', 'breadcrumbs_post_visibility', '2');
	vara_breadcrumbs($vara_page_breadcrumb, get_theme_mod('breadcrumbs_separator'));

	do_action('vara_open_container'); // Add container when sidebar is displayed
	?>
	<div class="gs-blog-post-single large-pt large-pb">
		<div class="<?php echo esc_attr($vara_row_class) ?>">
			<div class="<?php echo esc_attr($vara_posts_class) ?>">
				<div <?php post_class( 'gs-blog-post-single-holder gs-blog-post' ); ?> id="post-<?php the_ID(); ?>">
					<div class="gs-blog-post-single-top">
						<?php if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '3') { ?>
						<div class="container">
							<?php } // Remove divs when sidebar is not displayed ?>
							<?php if (get_field('blog_post_thumbnail') == '4' && get_field('blog_post_custom_thumbnail')) : ?>
								<div class="entry-thumbnail">
									<img src="<?php echo esc_url(get_field('blog_post_custom_thumbnail')) ?>">
								</div>
							<?php elseif (has_post_thumbnail() && vara_inherit_option('blog_post_thumbnail', 'blog_post_thumbnail', '1') == '1') : ?>
								<div class="entry-thumbnail">
									<?php the_post_thumbnail() ?>
								</div>
							<?php endif; ?>
							<?php if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '3') { ?>
							<div class="row">
								<div class="col-md-10 offset-md-1">
									<?php } // Remove divs when sidebar is not displayed ?>
									<div class="entry-content">
										<div class="entry-details-meta">
                                            <span class="entry-meta-date gs-divider">
                                                <span><?php the_time(get_option('date_format')) ?></span>
                                            </span>
											<?php get_template_part('tpls/taxonomy/categories') ?>
										</div>
										<?php
										/**
										 * Post Title
										 */
										if (vara_inherit_option('general_title', 'general_title_post', '1') == '1') {
											the_title('<h2 class="entry-details-title">', '</h2>');
										}
										?>
										<div class="entry-content-inner gs-cl">
											<?php the_content() ?>
										</div>
										<?php wp_link_pages(array('before' => '<div class="gs-pagination gs-pagination-pages"><span class="gs-pages-title">' . esc_attr__( 'Pages:', 'vara' ) . '</span><div class="gs-pagination-pages__numbers">', 'after' => '</div></div>')); ?>
										<?php paginate_links() ?>
										<?php if (vara_inherit_option('blog_post_share', 'blog_post_share', '2') == '1') : ?>
                                            <div class="gs-blog-post-share">
												<?php get_template_part('tpls/extra/share') ?>
                                            </div>
										<?php endif; ?>
									</div>
									<?php get_template_part('tpls/extra/author-box') ?>
                                    <?php get_template_part('tpls/single/navigation'); ?>
									<?php if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '3') { ?>
								</div>
							</div>
						</div>
					<?php } // Remove divs when sidebar is not displayed ?>
					</div>
					<?php
					/**
					 * Related
					 */
					$vara_related_template = get_field('related_posts') == '2' ? get_field('related_posts_template') : get_theme_mod('blog_post_related_template');

					if (vara_inherit_option('related_posts', 'blog_post_related', '2') == '1' && $vara_related_template) {
						echo vara_get_custom_template($vara_related_template);
					}

					if (vara_inherit_option('blog_post_share', 'blog_post_share', '2') == '1' || comments_open() || get_comments_number()) {
						?>
						<div class="gs-blog-post-footer">
							<?php if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '3') { ?>
							<div class="container">
								<div class="row">
									<div class="col-md-10 offset-md-1">
										<?php } // Remove divs when sidebar is not displayed ?>
										<?php if ( comments_open() || get_comments_number() ) : ?>
                                            <!-- Start #comments -->
											<?php comments_template('', true); ?>
                                            <!-- End #comments -->
										<?php endif; ?>
										<?php if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') == '3') { ?>
									</div>
								</div>
							</div>
						<?php } // Remove divs when sidebar is not displayed ?>
						</div>
					<?php } ?>
				</div>
			</div>
			<?php if (vara_inherit_option('blog_post_sidebar', 'blog_post_sidebar', '2') != '3' && is_active_sidebar('main-sidebar')) : ?>
				<div class="<?php echo esc_attr($vara_sidebar_class) ?>">
					<div class="sidebar-container">
						<?php get_sidebar() ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
	do_action('vara_close_container'); // Close container when sidebar is displayed

endwhile; endif;

get_footer(); ?>