<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php
    /**
     * Queried Object
     *
     * In case it is shop page get_queried_object won't
     * work, it needs to be changed to a custom WooCommerce
     * function wc_get_page_id.
     */
    $vara_queried_object = class_exists('WooCommerce') && is_shop() ? wc_get_page_id('shop') : get_queried_object();

    /**
     * Redirect
     */
    if (get_field('general_redirect', $vara_queried_object) && get_field('general_redirect_url', $vara_queried_object)) {
	    wp_redirect(get_field('general_redirect_url', $vara_queried_object));
	    exit;
    }

    wp_head();
    ?>
</head>
<body <?php body_class(); ?>>

    <?php wp_body_open(); ?>

    <?php
        /**
         * Borders
         */
        if (vara_inherit_option('theme_borders', 'theme_borders', '2') == '1') {
            get_template_part('tpls/borders/base');
        }
    ?>

	<div class="site-content">

        <?php
        /**
         * Header Visibility
         */
        if (vara_inherit_option('header_visibility', 'header_visibility', '1') == '2' && !is_search()) {
            add_filter('vara_display_header', '__return_false');
        }

        /**
         * Type
         */
        $vara_header_type = vara_inherit_option('header_type', 'header_type', '1');
        $vara_header_template = '';
        if (get_field('header_type', get_queried_object()) == '1') {
            $vara_header_template = get_theme_mod('header_template', '');
        } elseif (get_field('header_type', get_queried_object()) == '3' && get_field('header_template')) {
            $vara_header_template = get_field('header_template');
        } else {
            $vara_header_template = get_theme_mod('header_template', '');
        }

        /**
         * Sticky Type
         */
        $vara_header_sticky_template = '';
        if (get_field('header_transparency') == '1' && $vara_header_type == '2') {
            $vara_header_sticky_template = get_theme_mod('header_sticky_template');
        } elseif (get_field('header_sticky_template') && $vara_header_type == '2') {
            $vara_header_sticky_template = get_field('header_sticky_template');
        }

        /*
        * Header Options
        *
        * Variables are attached via a custom
        * function which inherits the page values
        * incase the options is set at Inherit
        */
        $vara_header_skin = vara_inherit_option('header_skin', 'header_skin', '1');
        $vara_header_position = vara_inherit_option('header_position', 'header_position', '1');
        $vara_header_transparency = vara_inherit_option('header_transparency', 'header_transparency', '1');
        $vara_header_autohide = vara_inherit_option('header_autohide', 'header_autohide', '1');
        $vara_header_container = vara_inherit_option('header_container', 'header_container', '2');

        $header_wrapper_class = ['gs-site-header-holder'];
        $header_class = ['gs-site-header-default'];
        $header_sticky_template_class = ['gs-template-header', 'gs-template-header-is-sticky'];
        $header_template_class = ['gs-template-header'];

        // Skin
        ($vara_header_skin == '2' && !is_search()) ? $header_class[] = 'gs-site-header-light' : '';

        // Position
        ($vara_header_position == '2' && !is_search()) || is_404() ? $header_wrapper_class[] = 'header-is-absolute' : '';
        $vara_header_position == '2' ? $header_template_class[] = 'gs-template-header--absolute' : '';

        // Transparency
        if ($vara_header_transparency == '2') {
            $header_wrapper_class[] = 'header-is-sticky';

            // Sticky Enabled & Skin Light
            $vara_header_skin == '2' ? $header_wrapper_class[] = 'header-sticky-scheme' : '';

            // Sticky Enabled & Position Static
            $vara_header_position == '1' ? $header_wrapper_class[] = 'gs-site-header-default-height' : '';

            // Sticky Enabled & Autohide On
            $vara_header_autohide == '1' ? $header_wrapper_class[] = 'gs-smart-header' : '';
            $vara_header_autohide == '1' ? $header_sticky_template_class[] = 'gs-template-smart-header' : '';
        }

        // Container
        $vara_header_container == '2' ? $header_class[] = 'gs-site-header-full-width' : '';

        /*
        * Modify Classes for Responsive
        *
        * Replaces classes from default to responsive
        * in wrapper and in header class
        */
        $header_responsive_wrapper_class = $header_responsive_class = [];

        $header_wrapper_class ? $header_responsive_wrapper_class = str_replace('site-header', 'mobile-header', $header_wrapper_class) : '';
        $header_class ? $header_responsive_class = str_replace('site-header', 'mobile-header', $header_class) : '';

        // Display Header Filter
        if ((apply_filters('vara_display_header', true) && $vara_header_type != '2') || is_search()) :
            ?>
            <div class="<?php echo esc_attr(implode(' ', $header_responsive_wrapper_class)) ?>">
                <div class="gs-site-header <?php echo esc_attr(implode(' ', $header_responsive_class)) ?>">
			        <?php get_template_part('tpls/header/menu/responsive') ?>
                </div>
            </div>

            <div class="<?php echo esc_attr(implode(' ', $header_wrapper_class)) ?>">
                <div class="gs-site-header <?php echo esc_attr(implode(' ', $header_class)) ?>">
			        <?php get_template_part('tpls/header/menu/primary') ?>

                    <?php get_template_part('tpls/header/search/base'); ?>
                </div>
            </div>
	        <?php

	        get_template_part('tpls/header/off-canvas-sidebar/base');

	        // End of Display Header Filter
        endif;

        // Elementor
        if ($vara_header_type == '2' && $vara_header_template && apply_filters('vara_display_header_template', true) && !is_search()) :
        ?>
            <div class="gs-template-header-wrapper">
		        <?php if ($vara_header_transparency == '2' && $vara_header_sticky_template) : ?>
                    <div class="<?php echo esc_attr(implode(' ', $header_sticky_template_class)) ?>">
				        <?php echo vara_get_custom_template($vara_header_sticky_template) ?>
                    </div>
		        <?php endif; ?>

                <div class="<?php echo esc_attr(implode(' ', $header_template_class)) ?>">
			        <?php echo vara_get_custom_template($vara_header_template) ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="gs-content-wrapper">

            <?php
            /**
             * Vertical Lines
             */
            $vara_vertical_lines = vara_inherit_option('vertical_lines', 'vertical_lines', '1');
            $vara_vertical_lines_color = vara_inherit_option('vertical_lines_color', 'vertical_lines_color', '1');
            $vara_vertical_lines_class = '';

            if ( $vara_vertical_lines_color == '1' ) {
	            $vara_vertical_lines_class = 'lines-light';
            } else {
	            $vara_vertical_lines_class = 'lines-dark';
            }

            if ( $vara_vertical_lines == '1' ) : ?>
                <div class="gs-vertical-lines <?php echo esc_attr($vara_vertical_lines_class); ?>">
                    <div class="gs-vertical-line"></div>
                    <div class="gs-vertical-line"></div>
                    <div class="gs-vertical-line"></div>
                    <div class="gs-vertical-line"></div>
                    <div class="gs-vertical-line"></div>
                    <div class="gs-vertical-line"></div>
                </div>
	        <?php endif; ?>
