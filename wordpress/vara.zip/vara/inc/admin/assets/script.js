var bodyClasses = Array.from(document.querySelector('body').classList);
var portfolioItemSettings = document.querySelector(
  '.acf-tab-button[data-key=field_5ecf4c62fead8]'
);
var portfolioItemGallery = document.querySelector(
  '.acf-tab-button[data-key=field_5ecf4dc064b86]'
);
var portfolioItemTabs = document.querySelector(
  '.acf-tab-button[data-key=field_5ecf4dea64b88]'
);
var productTab = document.querySelector(
  '.acf-tab-button[data-key=field_5ed0779b7c8eb]'
);
var postTab = document.querySelector(
  '.acf-tab-button[data-key=field_5ed07e6ce3f40]'
);

var relatedTab = document.querySelector(
  '.acf-tab-button[data-key=field_5ed084c82e443]'
);

// Portfolio Item Settings
if (
  bodyClasses.includes('post-type-portfolio') === false &&
  (portfolioItemSettings || portfolioItemGallery || portfolioItemTabs)
) {
  portfolioItemSettings.parentElement.style.display = 'none';
  portfolioItemGallery.parentElement.style.display = 'none';
  portfolioItemTabs.parentElement.style.display = 'none';
}

// Product Settings
if (bodyClasses.includes('post-type-product') === false && productTab) {
  productTab.parentElement.style.display = 'none';
}

// Post Settings
if (bodyClasses.includes('post-type-post') === false && postTab) {
  postTab.parentElement.style.display = 'none';
}

// Related
if (
  bodyClasses.includes('post-type-post') == false &&
  bodyClasses.includes('post-type-portfolio') == false &&
  relatedTab
) {
  relatedTab.parentElement.style.display = 'none';
}
