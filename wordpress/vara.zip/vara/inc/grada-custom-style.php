<?php
/**
 * Custom Style
 */

if ( function_exists('grada_color_lightness') && function_exists('grada_hexToRgb') ) {
	function vara_custom_style() {
		$vara_color_output = [];

		/**
		 * Body Color
		 */
		$vara_bg_color = get_theme_mod('style_bg_color', '#FFFFFF');

		if ($vara_bg_color && ($vara_bg_color != '#FFFFFF' && $vara_bg_color != '#ffffff')) {
			// Color
			$vara_color_output[] = 'html, body, .site-content .gs-content-wrapper, input, textarea, .select2-container--default .select2-selection--single { background-color: '. $vara_bg_color .' }';

			// Background Color Important
			$vara_color_output[] = implode(',', [
					'.gs-site-footer .footer-widgetized-area'
				]) . '{ background-color: '. $vara_bg_color .' !important}';

			// Background Color Darken (3%) Important
			$vara_color_output[] = implode(',', [
					'.gs-site-footer .subfooter-area'
				]) . '{ background-color: hsl('. grada_color_lightness(explode(', ', grada_hexToRgb($vara_bg_color)), -3) .') !important}';
		}

		/**
		 * Main Color
		 */
		$vara_main_color = get_theme_mod('style_main_color', '#f08923');

		if ($vara_main_color && ( $vara_main_color != '#f08923')) {

			// Color
			$vara_color_output[] = implode(',', [
					'a:not(button):hover',
					'a:not(button).active',
					'.woocommerce .star-rating',
					'.woocommerce .star-rating::before',
					'.breadcrumb-list .breadcrumb-list-item a:hover',
					'.woocommerce .woocommerce-shipping-calculator a',
					'.woocommerce .single-product .gs-product-summary .price',
					'.woocommerce .single-product .gs-product-summary .product_meta > span a',
					'.gs-comments .gs-comments-list .page-numbers.next:hover',
					'.gs-comments .gs-comments-list .page-numbers.prev:hover',
					'.gs-pagination ul.page-numbers li.active a',
					'.gs-post-nav .post-nav-link a:hover .gs-post-nav-title',
					'.gs-blog-post .entry-details-meta .gs-sticky-post',
					'.gs-blog-post .entry-meta-author .author-name a:hover',
					'.gs-site-header.gs-mobile-header-default .mobile-navigation nav ul.menu li.menu-item a:hover',
					'.gs-site-header.gs-mobile-header-default .mobile-navigation nav ul.menu li.menu-item.current_page_ancestor > a',
					'.gs-site-header.gs-mobile-header-default .mobile-navigation nav ul.menu li.menu-item.current_page_item > a',
					'.gs-woo-page .product-holder .entry-details .gs-product-cats a:hover',
					'.gs-site-footer .subfooter-area .subfooter-area-inner .subfooter-social-network ul li a:hover',
					'.woocommerce .cart_totals table td[data-title="Total"] span',
					'.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li a:hover',
					'.gs-gallery-images .gs-gallery-item .gallery-item-title a:hover',
					'.mobile-nav-menu nav ul.menu li.menu-item a:hover',
					'.mobile-nav-menu nav ul.menu li.menu-item.current_page_ancestor > a',
					'.mobile-nav-menu nav ul.menu li.menu-item.current_page_item > a',
				]) . '{ color: '. $vara_main_color .' }';

			// Color Important
			$vara_color_output[] = implode(',', [
					'.gs-btn.gs-btn-loading',
					'.gs-btn.gs-btn-loading:hover',
					'.gs-btn.gs-btn-accent.gs-btn-loading',
					'.woocommerce table td.product-remove a:hover',
					'.gs-close-btn svg:hover',
					'.woocommerce .single-product .woocommerce-tabs ul.tabs li a:hover',
					'.woocommerce .single-product .woocommerce-tabs ul.tabs li.active a',
				]) . '{ color: '. $vara_main_color .' !important}';

			// Background Color
			$vara_color_output[] = implode(',', [
					'.elementor-button',
					'mark',
					'.gs-btn.gs-btn-accent',
					'.scrollto-top.gotop-dark',
					'.tagcloud a:hover',
					'ul.menu.site-header-menu li.menu-item > a:after',
					'ul.menu.site-header-menu li.menu-item.menu-item-has-children > ul.sub-menu li.menu-item a:after',
					'.gs-filters ul li a:after',
					'.gs-filters ul li a.active:after',
					'.gs-progress-bar .gs-progress-bar-wrapper .gs-progress-bar-fill span',
					'.gs-pagination ul.page-numbers li a.current, .gs-pagination ul.page-numbers li span.current',
					'.gs-pagination.gs-pagination-pages .gs-pagination-pages__numbers .post-page-numbers.current',
					'.header-shopping-cart .header-shopping-cart-icon span',
					'.menu-navigation-regular ul li.menu-item.menu-item-has-children > ul.sub-menu li.menu-item a:after',
					'.menu-navigation-regular ul li.menu-item > a:after',
					'.menu-navigation-vertical ul li a:after',
				]) . '{ background-color: '. $vara_main_color .' }';

			// Background Color Selection
			$vara_color_output[] = implode(',', [
					'::-moz-selection'
				]) . '{ background-color: '. $vara_main_color .' }';

			// Background Color Selection
			$vara_color_output[] = implode(',', [
					'::selection'
				]) . '{ background-color: '. $vara_main_color .' }';

			// Background Color Important
			$vara_color_output[] = implode(',', [
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input',
				]) . '{ background-color: '. $vara_main_color .' !important}';

			// Border Color
			$vara_color_output[] = implode(',', [
					'.gs-subscribe input[type="email"]:focus',
					'.gs-btn.gs-btn-accent',
					'.woocommerce .blockUI.blockOverlay::before',
					'.woocommerce .loader::before',
					'.woocommerce .single-product .woocommerce-tabs ul.tabs li a:hover',
					'.woocommerce .single-product .woocommerce-tabs ul.tabs li.active a',
				]) . '{ border-color: '. $vara_main_color .' }';

			// Border Color Important
			$vara_color_output[] = implode(',', [
					'.select2.select2-container.select2-container--default.select2-container--open .select2-selection--multiple',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input'
				]) . '{ border-color: '. $vara_main_color .' !important}';

		}

		/**
		 * Headings
		 */
		$vara_headings_color = get_theme_mod('style_headings_color', '#212121');

		if ($vara_headings_color && ($vara_headings_color != '#212121')) {

			// Color
			$vara_color_output[] = implode(', ', [
					'h1','.h1','h2','.h2','h3','.h3','h4','.h4','h5','.h5','h6','.h6',
					'dl dt', 'blockquote', 'table th a', 'table td#today', 'table thead td', 'table thead th',
					'legend', 'input', 'textarea', 'label', 'select', '.gs-dark-form .button:hover', '.gs-btn.gs-btn-dark',
					'.gs-btn.gs-btn-white-color:hover', '.select2 .selection .select2-selection .select2-selection__arrow',
					'body .select2-container .select2-dropdown .select2-results .select2-results__options .select2-results__option[data-selected=\'true\']',
					'.gs-blog-post .entry-meta-author .author-name a',
					'.gs-site-header.gs-mobile-header-default .mobile-navigation nav ul.menu li.menu-item a',
					'.menu-navigation-vertical ul li a',
					'.select2-container--default .select2-selection--single .select2-selection__rendered',
					'.gs-logo.gs-logo-text a', '.scrollto-top.gotop-light svg', '.woocommerce table tfoot tr:last-child th',
					'.woocommerce table tfoot tr:last-child td', '.gs-fullscreen-search .gs-fullscreen-search-inner .search-wrapper-inner .search-wrapper-form .search-form-button span', '.widget.widget_rss .widget-title-outer .widgettitle .rsswidget', '.widget ul li a',
					'.widget.widget_recent_comments ul li span', '.site-footer-dark .widget.widget_tag_cloud .tagcloud a',
					'.dark-fixed-section .widget.widget_tag_cloud .tagcloud a', '.social-network-links ul li a',
					'.gs-filters ul li a', '.woocommerce .single-product .gs-product-summary .quantity input', '.woocommerce .single-product .gs-product-summary .product_meta > span', '.woocommerce .single-product .woocommerce-tabs ul.tabs li a',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel.woocommerce-Tabs-panel--additional_information table tr th',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper #review_form .comment-reply-title',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .comment-form-rating label',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input',
					'.woocommerce-Reviews .commentlist .review .comment_container .comment-text .meta .woocommerce-review__author',
					'.gs-progress-bar .gs-progress-bar-text', '.gs-comments .gs-comments-title',
					'.gs-comments .gs-comments-list .gs-comment .gs-comment-body .gs-comment-author .comment-reply-link',
					'.gs-comments .gs-comments-list .page-numbers:not(.next):not(.prev)',
					'.gs-comments .gs-comments-list .page-numbers.next, .gs-comments .gs-comments-list .page-numbers.prev',
					'.gs-comments .gs-comments-list .comment-respond .gs-comments-title',
					'.gs-comments .gs-comment-form .comment-respond .gs-comments-title',
					'.gs-comments .gs-comment-closed .gs-comment-closed-title',
					'.gs-page-heading-outer .gs-page-heading-inner .gs-page-heading-title',
					'.gs-pagination ul.gs-pages-list li a', '.gs-pagination.gs-pagination-pages .gs-pages-title',
					'.gs-pagination.gs-pagination-pages .gs-pagination-pages__numbers span:not(.post-page-numbers)',
					'.gs-post-nav .post-nav-link a .gs-post-nav-text .gs-post-nav-title',
					'.gs-blog-post .entry-details-title a', '.gs-portfolio-item .entry-overlay-wrapper > a',
					'.gs-portfolio-item .entry-details .entry-details-title a',
					'.header-shopping-cart .header-shopping-cart-icon',
					'.dropdown-shopping-cart .dropdown-cart-list .dropdown-cart-list-item .dropdown-cart-item-info .title a',
					'.dropdown-shopping-cart .dropdown-cart-list .dropdown-cart-list-item .dropdown-cart-item-remove',
					'.dropdown-cart-bottom .dropdown-cart-subtotal .subtotal', '.dropdown-cart-bottom .dropdown-cart-subtotal .price .amount',
					'.gs-site-header.gs-site-header-light .header-shopping-cart .header-shopping-cart-icon span.cart-number',
					'.gs-woo-page .product-holder .entry-details .entry-details-title a',
					'.gs-page-404 .gs-page-heading-outer .gs-page-heading-inner .gs-page-heading-title h1',
					'.woocommerce .woocommerce-cart-form table td::before',
					'.woocommerce .woocommerce-cart-form table .actions .coupon #coupon_code',
					'.woocommerce .cart_totals table th',
					'.woocommerce-checkout .woocommerce-checkout-review-order table tr.order-total td strong',
					'.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li a',
					'.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a svg',
					'body .select2-container .select2-dropdown .select2-results .select2-results__options .select2-results__option[aria-selected=\'true\']',
					'a:not(button)',
				]) . '{ color: '. $vara_headings_color .' }';

			// Color Important
			$vara_color_output[] = implode(',', [
					'.gs-subscribe-light input[type=\'submit\']', '.gs-subscribe-light input[type=\'submit\']:hover',
					'.gs-dark-form input[type=\'submit\']:hover', '.gs-dark-form button:hover', '.gs-dark-form .button:hover',
					'.woocommerce .sidebar-container input[type=\'submit\']', '.woocommerce .sidebar-container button',
					'.woocommerce .sidebar-container .button', '.gs-btn.gs-btn-dark.gs-btn-loading',
					'.woocommerce table td.product-remove a', 'ul.menu.site-header-menu li.menu-item.menu-item-has-children > ul.sub-menu li.menu-item a', '.woocommerce .single-product .woocommerce-tabs ul.tabs li a', '.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input', '.gs-blog-post-single .gs-blog-post-single-holder .gs-blog-post-single-top .entry-content .entry-content-inner .post-password-form input[type=\'submit\']',
					'ul.menu.site-header-menu li.menu-item > a',
				]) . '{ color: '. $vara_headings_color .' !important}';

			// Fill
			$vara_color_output[] = implode(',', [
					'.gs-pagination .gs-pages-arrow a svg', '.gs-post-nav .post-nav-link a:hover svg',
					'.gs-post-nav .post-nav-link--back a:hover svg', '.gs-site-header.gs-mobile-header-default .mobile-header-btn svg',
					'.gs-site-header .site-header-tools > * svg',
				]) . '{ fill: '. $vara_headings_color .'}';

			// Background Color
			$vara_color_output[] = implode(',', [
					'.search-form .search-form-button span:hover',
					'input[type=\'submit\']:hover', 'button:hover', '.button:hover',
					'.gs-btn.gs-btn-accent:hover', '.gs-btn.gs-btn-dark:hover',
					'.select2-results__option.select2-results__option--highlighted',
					'body .select2-container .select2-dropdown .select2-results .select2-results__options .select2-results__option.select2-results__option--highlighted',
					'.gs-product-badge', '.gs-fullscreen-search .gs-fullscreen-search-inner .search-wrapper-close:before',
					'.gs-fullscreen-search .gs-fullscreen-search-inner .search-wrapper-close:after',
					'.gs-woo-page .product-holder .gs-add-to-cart-btn:hover',
					'.gs-site-footer.site-footer-dark .footer-widgetized-area',
					'.gs-site-footer.site-footer-dark .subfooter-area'
				]) . '{ background-color: '. $vara_headings_color .'  }';

			// Background Color Important
			$vara_color_output[] = implode(',', [
					'.dropdown-cart-bottom .dropdown-cart-btn .button:hover',
					'.woocommerce .button:hover',
					'.woocommerce .sidebar-container input[type=\'submit\']:hover',
					'.woocommerce .sidebar-container button:hover',
					'.woocommerce .sidebar-container .button:hover',
					'.ui-slider .ui-slider-range',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input:hover',
					'.gs-blog-post-single .gs-blog-post-single-holder .gs-blog-post-single-top .entry-content .entry-content-inner .post-password-form input[type=\'submit\']:hover',
				]) . '{ background-color: '. $vara_headings_color .' !important}';

			// Border Color
			$vara_color_output[] = implode(',', [
					'input:focus', 'textarea:focus', 'input[type=\'submit\']:hover', 'button:hover', '.button:hover ',
					'.gs-btn.gs-btn-accent:hover', '.gs-btn.gs-btn-dark:hover', '.gs-comments .gs-comments-list .page-numbers:not(.next):not(.prev):hover, .gs-comments .gs-comments-list .page-numbers:not(.next):not(.prev).current',
					'.dropdown-cart-bottom .dropdown-cart-btn .button:hover', '.gs-woo-page .product-holder .gs-add-to-cart-btn:hover',
					'.gs-fullscreen-search .gs-fullscreen-search-inner .search-wrapper-inner .search-wrapper-form input[type=\'search\']',
				]) . '{ border-color: '. $vara_headings_color .' }';

			// Border Color Important
			$vara_color_output[] = implode(',', [
					'.woocommerce .button:hover',
					'.woocommerce .sidebar-container input[type=\'submit\']:hover',
					'.woocommerce .sidebar-container button:hover',
					'.woocommerce .sidebar-container .button:hover',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input:hover',
					'.gs-blog-post-single .gs-blog-post-single-holder .gs-blog-post-single-top .entry-content .entry-content-inner .post-password-form input[type=\'submit\']:hover',
				]) . '{ border-color: '. $vara_headings_color .' !important}';
		}

		/**
		 * Paragraphs
		 */
		$vara_paragraphs_color = get_theme_mod('style_paragraphs_color', '#4b575c');

		if ($vara_paragraphs_color && $vara_paragraphs_color != '#4b575c') {

			// Color
			$vara_color_output[] = implode(',', [
					'body',
					'select',
					'.woocommerce .star-rating::before',
					'.woocommerce table tr.shipping td label',
					'.woocommerce table tr.shipping td label span',
					'.gs-divider ul li a',
					'.widget.widget_rss ul li',
					'.widget.widget_recent_entries ul li span',
					'.woocommerce-info', '.woocommerce-message', '.woocommerce-error',
					'.woocommerce .single-product .gs-product-summary .product_meta > span span',
					'.gs-post-nav .post-nav-link a .gs-post-nav-text .gs-post-nav-subtitle',
					'.gs-blog-post .entry-details-meta',
					'.dropdown-shopping-cart .dropdown-cart-list .dropdown-cart-list-item .dropdown-cart-item-info .quantity',
					'.dropdown-cart .widget_shopping_cart_content .mini-cart-empty-message p',
					'.dropdown-cart .dropdown-shopping-cart .dropdown-cart-list .dropdown-cart-list-item .dropdown-cart-item-info .quantity',
					'.gs-woo-page .product-holder .entry-details .gs-product-cats a',
					'.gs-woo-page .product-holder .entry-details .price del',
					'.gs-site-footer.site-footer-light .subfooter-area .subfooter-area-inner .subfooter-social-network ul li a',
					'.gs-portfolio-single-item .gs-portfolio-content-top .portfolio-single-subtitle',
					'.woocommerce-checkout .woocommerce-checkout-review-order table tr td strong',
					'.woocommerce ul.order_details li',
				]) . '{ color: '. $vara_paragraphs_color .'}';

			// Placeholder Color
			$vara_color_output[] = implode(',', [
					'input::-webkit-input-placeholder',
					'textarea::-webkit-input-placeholder',
					'input:-moz-placeholder',
					'textarea:-moz-placeholder',
					'input::-moz-placeholder',
					'textarea::-moz-placeholder',
					'input:-ms-input-placeholder',
					'textarea:-ms-input-placeholder'
				]) . '{ color: '. $vara_paragraphs_color .' }';

			// Fill
			$vara_color_output[] = implode(',', [
					'.gs-post-nav .post-nav-link a svg',
				]) . '{ fill: '. $vara_paragraphs_color .' }';

			// Background Color
			$vara_color_output[] = implode(',', [
					'.scrollto-top.gotop-light', '.gs-product-badge.out-of-stock',
					'.product-item--left-image .entry-thumbnail .gs-product-badge.out-of-stock',
					'.product-item--meta-overlay .entry-thumbnail .gs-product-badge.out-of-stock',
				]) . '{ background-color: '. $vara_paragraphs_color .' }';
		}

		/**
		 * Border
		 */
		$vara_border_color = get_theme_mod('style_border_color', '#e5e5e5');

		if ($vara_border_color && $vara_border_color != '#e5e5e5') {

			// Border Color
			$vara_color_output[] = implode(',', [
					'select', '.gs-btn.gs-btn-dark', 'body .select2-container .select2-dropdown .select2-search input',
					'.woocommerce form .form-row.woocommerce-validated input.input-text',
					'.woocommerce form.login, .woocommerce form.register',
					'.woocommerce .woocommerce-cart-form table .actions .coupon #coupon_code',
					'.woocommerce .quantity .quantity-nav .quantity-button',
					'.woocommerce .quantity .quantity-nav .quantity-button.quantity-up',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel',
					'.gs-post-nav',
				]) . '{ border-color: '. $vara_border_color .'}';

			//  Border Color Important
			$vara_color_output[] = implode(',', [
					'.woocommerce .sidebar-container input[type=\'submit\']',
					'.woocommerce .sidebar-container button',
					'.woocommerce .sidebar-container .button',
					'.woocommerce .quantity input[type=\'number\']',
					'.woocommerce .single-product .woocommerce-tabs .woocommerce-Tabs-panel .woocommerce-Reviews #review_form_wrapper .comment-form .form-submit input',
					'.gs-blog-post-single .gs-blog-post-single-holder .gs-blog-post-single-top .entry-content .entry-content-inner .post-password-form input[type=\'submit\']',
					'.woocommerce-checkout .checkout_coupon',
				]) . '{ border-color: '. $vara_border_color .' !important}';

			// Background Color
			$vara_color_output[] = implode(',', [
					'.ui-slider',
				]) . '{ background-color: '. $vara_border_color .' !important}';
		}

		/**
		 * Pattern
		 */
		$vara_pattern_color = get_theme_mod('style_pattern_color', '#f7f7f7');

		if ($vara_pattern_color && $vara_pattern_color != '#f7f7f7') {

			// Background Color
			$vara_color_output[] = implode(',', [
					'.woocommerce-info', '.woocommerce-message', '.woocommerce-error',
					'.gs-page-heading-outer', '.gs-breadcrumb', '.gs-portfolio-item .entry-overlay-wrapper .entry-thumbnail__overlay',
					'pre', 'code', 'input', 'textarea', '.select2 .selection .select2-selection .select2-selection__rendered .select2-selection__choice', 'body .select2-container .select2-dropdown', 'body .select2-container .select2-dropdown .select2-results .select2-results__options .select2-results__option[data-selected=\'true\']', '.tagcloud a', '#add_payment_method #payment div.payment_box',
					'.woocommerce-cart #payment div.payment_box', '.woocommerce-checkout #payment div.payment_box',
					'body .select2-container .select2-dropdown .select2-results .select2-results__options .select2-results__option[aria-selected=\'true\']',
				]) . '{ background-color: '. $vara_pattern_color .'}';

			// Background Color Important
			$vara_color_output[] = implode(',', [
					'.select2 .selection .select2-selection',
				]) . '{ background-color: '. $vara_pattern_color .' !important}';

			// Border Color Important
			$vara_color_output[] = implode(',', [
					'.select2.select2-container.select2-container--default.select2-container--open .selection .select2-selection',
					'.select2 .selection .select2-selection',
				]) . '{ border-color: '. $vara_pattern_color .' !important}';

			// Border Color
			$vara_color_output[] = implode(',', [
					'body .select2-container .select2-dropdown',
					'.select2 .selection .select2-selection .select2-selection__rendered .select2-selection__choice',
				]) . '{ border-color: '. $vara_pattern_color .'}';

		}

		/**
		 * Theme Borders
		 */
		$vara_theme_borders = get_field('theme_borders', get_queried_object()) == '1' ? get_theme_mod('theme_borders', '2') : get_field('theme_borders', get_queried_object()) - 1;
		$vara_theme_borders_thickness = get_field('theme_borders', get_queried_object()) == '1' ? get_theme_mod('theme_borders_thickness', 16) : get_field('theme_borders_thickness', get_queried_object());
		$vara_theme_borders_color = get_field('theme_borders', get_queried_object()) == '1' ? get_theme_mod('theme_borders_color', '#FFFFFF') : get_field('theme_borders_color', get_queried_object());

		if ($vara_theme_borders == '1') {
			// Thickness
			if ($vara_theme_borders_thickness && $vara_theme_borders_thickness != 16) {
				// Theme Borders
				$vara_color_output[] = implode(',', [
						'.gs-page-boundary-on .gs-page-boundary .gs-border-top',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-bottom'
					]) . '{ height: '. $vara_theme_borders_thickness .'px}';

				$vara_color_output[] = implode(',', [
						'@media (max-width: 991px) { .gs-page-boundary-on .gs-page-boundary .gs-border-top',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-bottom'
					]) . '{ height: '. $vara_theme_borders_thickness / 2 .'px} }';

				$vara_color_output[] = implode(',', [
						'.gs-page-boundary-on .gs-page-boundary .gs-border-left',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-right'
					]) . '{ width: '. $vara_theme_borders_thickness / 2 .'px}';

				$vara_color_output[] = implode(',', [
						'@media (min-width: 991px) { .gs-page-boundary-on .gs-page-boundary .gs-border-left',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-right'
					]) . '{ width: '. $vara_theme_borders_thickness .'px} }';

				// Theme Wrapper
				$vara_color_output[] = implode(',', [
						'.gs-page-boundary-on .site-content'
					]) . '{ margin: '. $vara_theme_borders_thickness / 2 .'px !important}';

				$vara_color_output[] = implode(',', [
						'@media (min-width: 991px) { .gs-page-boundary-on .site-content'
					]) . '{ margin: '. $vara_theme_borders_thickness .'px !important} }';

				// Sticky Header
				$vara_color_output[] = implode(',', [
						'.gs-page-boundary-on .site-content .header-is-sticky .gs-site-header'
					]) . '{ margin: '. $vara_theme_borders_thickness / 2 . 'px ' . $vara_theme_borders_thickness / 2 . 'px 0 ' . $vara_theme_borders_thickness / 2 .'px !important}';

				$vara_color_output[] = implode(',', [
						'@media (min-width: 991px) { .gs-page-boundary-on .site-content .header-is-sticky .gs-site-header'
					]) . '{ margin: '. $vara_theme_borders_thickness . 'px ' . $vara_theme_borders_thickness . 'px 0 ' . $vara_theme_borders_thickness .'px !important} }';

				// Admin Bar
				$vara_color_output[] = implode(',', [
						'.admin-bar.gs-page-boundary-on .header-is-sticky .gs-site-header'
					]) . '{ margin-top: calc(46px + '. $vara_theme_borders_thickness / 2 .'px) !important }';

				$vara_color_output[] = implode(',', [
						'@media (min-width: 991px) { .admin-bar.gs-page-boundary-on .header-is-sticky .gs-site-header'
					]) . '{ margin-top: calc(32px + '. $vara_theme_borders_thickness .'px) !important }}';

				// Parallax Footer
				$vara_color_output[] = implode(',', [
						'@media (min-width: 991px) { .gs-page-boundary-on.sticky-footer-on .site-footer-sticky'
					]) . '{ right: '. $vara_theme_borders_thickness .'px !important; bottom: '. $vara_theme_borders_thickness .'px !important; left: '. $vara_theme_borders_thickness .'px !important }}';

				// To Top
				$vara_color_output[] = implode(',', [
						'.scrollto-top'
					]) . '{ right: '. $vara_theme_borders_thickness / 2 .'px !important; bottom: '. $vara_theme_borders_thickness / 2 .'px !important; }';

				$vara_color_output[] = implode(',', [
						'@media (min-width: 991px) { .scrollto-top'
					]) . '{ right: '. $vara_theme_borders_thickness .'px !important; bottom: '. $vara_theme_borders_thickness .'px !important; }}';

			}

			// Color
			if ($vara_theme_borders_color && ($vara_theme_borders_color != '#FFFFFF' && $vara_theme_borders_color != '#ffffff')) {
				$vara_color_output[] = implode(',', [
						'.gs-page-boundary-on .gs-page-boundary .gs-border-top',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-bottom',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-left',
						'.gs-page-boundary-on .gs-page-boundary .gs-border-right'
					]) . '{ background-color: '. $vara_theme_borders_color .'}';
			}
		}

		return $vara_color_output ? implode(' ', $vara_color_output) : '';
	}
}