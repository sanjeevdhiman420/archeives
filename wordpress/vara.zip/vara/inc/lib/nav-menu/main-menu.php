<?php

if ( ! function_exists( 'grada_include_custom_walkers' ) ) {
	function grada_include_custom_walkers() {

		/**
		 * Include custom walkers
		 */
		include_once VARA_THEME_DIR . '/inc/lib/nav-menu/top-navigation-walker.php';

		do_action( 'grada_action_include_custom_walkers_nav' );
	}

	add_action( 'after_setup_theme', 'grada_include_custom_walkers' );
}