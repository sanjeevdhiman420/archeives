<?php
/**
 * Grada Functions
 */

/**
 * Open and close container tags
 *
 * Simply opens and closes the container tags,
 * theme uses it and finds helpful on files
 * that does not contain html tags.
 */
add_action('vara_open_container', 'vara_open_container');
add_action('vara_close_container', 'vara_close_container');
function vara_open_container() {
	?>
	<div class="container">
	<?php
}

function vara_close_container() {
	?>
	</div>
	<?php
}

/**
 * Comments
 *
 * Rewrites the comments for easier use.
 */
function vara_comments_open($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;

	switch ($depth) {
		case 1:
			$vara_comment_class = "col-md-12";
			break;
		case 2:
			$vara_comment_class = "col-md-11 offset-md-1";
			break;
		case 3:
			$vara_comment_class = "col-md-10 offset-md-2";
			break;
		case 4:
		default:
			$vara_comment_class = "col-md-9 offset-md-3";
			break;
	}

	$type = get_comment_type();

	switch ( $type ) {
		case 'trackback':
			$vara_comment_class .= " comment-no-avatar";
			break;
		case 'pingback':
			$vara_comment_class .= " comment-no-avatar";
			break;
		default:
			$vara_comment_class .= "";
	}
	?>
    <div class="gs-comment <?php echo esc_attr($vara_comment_class) ?>" id="comment-<?php echo esc_attr($comment->comment_ID); ?>">
		<?php if($comment->comment_type != 'pingback') : ?>
            <div class="gs-comment-avatar">
				<?php echo get_avatar($comment, 70) ?>
            </div>
		<?php endif; ?>
        <div class="gs-comment-body">
            <div class="gs-comment-author d-flex align-items-center">
                <h5 class="gs-comment-name"><?php echo esc_html($comment->comment_author) ?></h5>
                <div class="ml-auto">
					<?php
					/**
					 * Reply Link
					 */
					comment_reply_link(
						array_merge(
							$args,
							array(
								'reply_text' => esc_attr__('reply', 'vara'),
								'depth' => $depth,
								'max_depth' => $args['max_depth'],
							)
						),
						$comment
					);
					?>
                </div>
            </div>
            <div class="gs-comment-time">
				<?php comment_date(get_option('date_format')) ?>
				<?php comment_date(get_option('time_format')) ?>
            </div>
            <div class="gs-comment-text">
	            <?php comment_text(); ?>
            </div>
        </div>
    </div>
	<?php
}

function vara_comments_close() {}

function vara_comment_form_before() {
	?>
    <div class="row">
    <div class="col-12">
	<?php
}
add_action('comment_form_before', 'vara_comment_form_before');

function vara_comment_form_after() {
	?>
    </div>
    </div>
	<?php
}
add_action('comment_form_after', 'vara_comment_form_after');

/**
 * Inherit Option ACF to Customizer
 *
 * It accepts two different options, the field
 * from acf and the option from customizer, it
 * makes them ready to be used if the value
 * will be inherited or not.
 */
function vara_inherit_option($inherit, $customizer, $default_customizer, $archive = true) {
	/**
	 * Get Queried Object
	 *
	 * If the field is being called in taxonomy
	 * the term will be associated to the queried
	 * object as prefix.
	 *
	 * https://www.advancedcustomfields.com/resources/adding-fields-taxonomy-term/
	 */
	if (class_exists('WooCommerce') && is_shop()) {
		$term = wc_get_page_id('shop');
	} else if (is_tax() && isset(get_queried_object()->term_id)) {
		$term = 'term_' . get_queried_object()->term_id;
	} else {
		$term = get_queried_object();
	}

	/**
	 * Archive
	 *
	 * All archive pages and taxonomies should
	 * have get_queried_object as second parameter
	 * on the get_field otherwise the right value
	 * would not be returned.
	 */
	if ($archive == true) {
		$inherit = get_field($inherit, $term);
	} else {
		$inherit = get_field($inherit);
	}

	$customizer = get_theme_mod($customizer, $default_customizer);

	if (!$inherit) {
		$inherit = '1';
	}

	if (is_array($inherit)) {
		$inherit = $inherit[0];
	}

	if ($inherit == '1') {
		$inherit = $customizer;
	} else {
		$inherit = $inherit - 1;
	}

	return $inherit;
}

/**
 * Breadcrumbs
 *
 * Add support for parent and child pages, archives
 * custom post types and custom taxonomies
 */
function vara_breadcrumbs($visibility, $sep) {
	if ($visibility == '2') {
		return;
	}

	// Output
	$output = [];

	// Settings
	if ($sep) {
		$separator = $sep;
	} else {
		$separator = '|';
	}

	$home_title = esc_html__('Home', 'vara');

	if (class_exists('WooCommerce') && is_shop()) {
		$current_title = woocommerce_page_title(false);
	} elseif (is_author()) {
		$current_title = get_the_author();
	} elseif (is_archive()) {
		if (is_date()) {
			$current_title = get_the_date();
		} else {
			$current_title = single_term_title('', false);
		}
	} else {
		$current_title = get_the_title();
	}

	// If you have any custom post types with custom taxonomies, put the taxonomy name below (e.g. product_cat)
	$custom_taxonomy = 'project_cat';

	// Get the query & post information
	global $post, $wp_query;

	// Do not display on the homepage
	if (!is_front_page()) {

		if (is_archive() && is_tax() && !is_category() && !is_tag()) {
			// If post is a custom post type
			$post_type = get_post_type();

			// If it is a custom post type display name and link
			if ($post_type != 'post') {

				if (get_post_type_object($post_type)) {
					$post_type_object = get_post_type_object($post_type);
					$output[] = '<li class="breadcrumb-list-item">' . $post_type_object->labels->name . '</li>';
					$output[] = '<li class="breadcrumb-list-item breadcrumb-sep"> ' . $separator . ' </li>';
				}
			}
			$custom_tax_name = get_queried_object()->name;

			$output[] = '<li class="breadcrumb-list-item current">' . $custom_tax_name . '</li>';
		} elseif (is_category() || is_tag()) {
			$output[] = '<li class="breadcrumb-list-item current">' . single_cat_title('', false) . '</li>';
		} elseif (is_attachment()) {
			$output[] = '<li class="breadcrumb-list-item current">' . get_the_title(get_the_ID()) . '</li>';
		} elseif (is_single()) {

			// If post is a custom post type
			$post_type = get_post_type();

			// If it is a custom post type display name and link
			if ($post_type != 'post') {

				$post_type_object = get_post_type_object($post_type);

				$output[] = '<li class="breadcrumb-list-item">' . $post_type_object->labels->name . '</li>';
				$output[] = '<li class="breadcrumb-list-item breadcrumb-sep"> ' . $separator . ' </li>';
			}

			// Get post category info
			$category = get_the_category();

			if (!empty($category)) {

				// Get last category post is in
				$array_category = array_values($category);
				$last_category = end($array_category);

				// Get parent any categories and create array
				$get_cat_parents = rtrim(get_category_parents($last_category->term_id, true, ','), ',');
				$cat_parents = explode(',', $get_cat_parents);

				// Loop through parent categories and store in variable $cat_display
				$cat_display = '';
				foreach ($cat_parents as $parents) {
					$cat_display .= '<li class="breadcrumb-list-item">'. $parents .'</li>';
					$cat_display .= '<li class="breadcrumb-list-item breadcrumb-sep"> ' . $separator . ' </li>';
				}
			}
			// If it's a custom post type within a custom taxonomy
			if (get_post_type() == 'product') {
				$custom_taxonomy = 'product_cat';
			} elseif (get_post_type() == 'portfolio') {
				$custom_taxonomy = 'project_cat';
			}

			$taxonomy_exists = taxonomy_exists($custom_taxonomy);

			if (empty($last_category) && !empty($custom_taxonomy) && $taxonomy_exists) {
				$taxonomy_terms = !empty(get_the_terms($post->ID, $custom_taxonomy)) ? get_the_terms($post->ID, $custom_taxonomy) : '';
				if ($taxonomy_terms) {
					$cat_id         = $taxonomy_terms[0]->term_id;
					$cat_nicename   = $taxonomy_terms[0]->slug;
					$cat_link       = get_term_link($taxonomy_terms[0]->term_id, $custom_taxonomy);
					$cat_name       = $taxonomy_terms[0]->name;
				}
			}

			// Check if the post is in a category
			if (!empty($last_category)) {
				$output[] = wp_kses_post($cat_display);
				$output[] = '<li class="breadcrumb-list-item current">'. get_the_title() .'</li>';
			} elseif (!empty($cat_id)) {
				$output[] = '<li class="breadcrumb-list-item"><a href="'. esc_url($cat_link) .'">' . esc_attr($cat_name) . '</a></li>';
				$output[] = '<li class="breadcrumb-list-item breadcrumb-sep"> ' . $separator . ' </li>';
				$output[] = '<li class="breadcrumb-list-item current">' . get_the_title() . '</li>';
			} else {
				$output[] = '<li class="breadcrumb-list-item current">' . get_the_title() . '</li>';
			}
		} elseif (is_page()) {
			if ($post->post_parent) {

				// If child page, get parents
				$anc = get_post_ancestors($post->ID);

				// Get parents in the right order
				$anc = array_reverse($anc);

				// Parent page loop
				if (!isset($parents)) {
					$parents = null;
				}

				foreach ($anc as $ancestor) {
					$parents .= '<li class="breadcrumb-list-item"><a href="' . get_permalink($ancestor) . '">' . get_the_title($ancestor) . '</a></li>';
					$parents .= '<li class="breadcrumb-list-item breadcrumb-sep"> ' . $separator . ' </li>';
				}

				// Display parent pages
				$output[] = wp_kses_post($parents);

				$output[] = '<li class="breadcrumb-list-item current">' . get_the_title() . '</li>';
			} else {
				$output[] = '<li class="breadcrumb-list-item current">' . get_the_title() . '</li>';
			}
		} elseif (class_exists('WooCommerce') && is_shop()) {
			$output[] = '<li class="breadcrumb-list-item">' . woocommerce_page_title(false) . '</li>';
		} elseif (is_year()) {
			$output[] = '<li class="breadcrumb-list-item"><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a></li>';
		} elseif (is_month()) {
			// Year link
			$output[] = '<li class="breadcrumb-list-item"><a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a></li>';
			$output[] = '<li class="breadcrumb-list-item breadcrumb-sep"> ' . $separator . ' </li>';

			// Month display
			$output[] = '<li class="breadcrumb-list-item">' . get_the_time('M') . '</li>';
		} elseif (is_author()) {
			global $author;
			$userdata = get_userdata($author);
			$output[] = '<li class="breadcrumb-list-item current">' . $userdata->display_name . '</li>';
		} elseif (get_query_var('paged')) {
			$output[] = '<li class="breadcrumb-list-item">'. esc_html__('Page', 'vara') . get_query_var('paged') . '</li>';
		} elseif (is_search()) {
			$output[] = '<li class="breadcrumb-list-item">Search results for: ' . get_search_query() . '</li>';
		}

		if (is_search()) {
			echo sprintf(
				'<div class="gs-breadcrumb">
                    <div class="gs-breadcrumb-wrapper">
                        <div class="container">
                            <div class="row">
                                <div class="col-12 d-lg-flex align-items-center justify-content-between">
                                    <h3 class="gs-breadcrumb-title">%s</h3>
                                    <ul id="breadcrumbs" class="breadcrumb-list">
                                        <li class="breadcrumb-list-item"><a href="%s">%s</a></li>
                                        <li class="breadcrumb-list-item breadcrumb-sep">%s</li>
                                        %s
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>',
				esc_attr(get_search_query()),
				get_home_url(),
				$home_title,
				$separator,
				is_array($output) ? wp_kses_post(implode(' ', $output)) : wp_kses_post($output)
			);
		} else {
			echo sprintf(
				'<div class="gs-breadcrumb">
					<div class="gs-breadcrumb-wrapper">
					    <div class="container">
                            <div class="row">
                                <div class="col-12 d-lg-flex align-items-center justify-content-between">
                                    <h3 class="gs-breadcrumb-title">%s</h3>
                                    <ul id="breadcrumbs" class="breadcrumb-list">
                                        <li class="breadcrumb-list-item"><a href="%s">%s</a></li>
                                        <li class="breadcrumb-list-item breadcrumb-sep">%s</li>
                                        %s
                                    </ul>
                                </div>
                            </div>
                        </div>
					</div>
				</div>',
				esc_attr($current_title),
				get_home_url(),
				$home_title,
				$separator,
				is_array($output) ? wp_kses_post(implode(' ', $output)) : wp_kses_post($output)
			);
		}
	}
}

/**
 * Thumbnail Calculation
 *
 * A simple calculation which returns as padding
 * bottom the height of image, we use it to eleminate
 * the glitches of masonry when loading.
 */
function vara_thumbnail_calculation($thumbnail = 'full') {
	global $post;

	$image_data = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), $thumbnail);

	return 'padding-bottom: '. number_format($image_data[2] / $image_data[1] * 100, 6) .'% !important;';
}

// For simple images not thumbnails
function vara_image_calculation($image_id, $image_size = 'full') {
	$image_data = wp_get_attachment_image_src($image_id, $image_size);

	return 'padding-bottom: '. number_format($image_data[2] / $image_data[1] * 100, 6) .'% !important;';
}

/**
 * Social Media
 *
 * Incase visibility is false the function will return
 * also the type will be between icon and text, sorter
 * helps to add the social media you want.
 */
function vara_social_media($visibility, $sorter) {

	if ($visibility == '2') {
		return;
	}

	$vara_social_media_output = [];

	$vara_social_media = [
		'facebook' => [
			'url' => get_theme_mod('social_media_facebook'),
			'short_name' => 'Fb.'
		],
		'twitter' => [
			'url' => get_theme_mod('social_media_twitter'),
			'short_name' => 'Tw.'
		],
		'google_plus' => [
			'url' => get_theme_mod('social_media_google_plus'),
			'short_name' => 'G+.'
		],
		'vimeo' => [
			'url' => get_theme_mod('social_media_vimeo'),
			'short_name' => 'Vm.'
		],
		'dribbble' => [
			'url' => get_theme_mod('social_media_dribbble'),
			'short_name' => 'Dr.'
		],
		'pinterest' => [
			'url' => get_theme_mod('social_media_pinterest'),
			'short_name' => 'Pi.'
		],
		'youtube' => [
			'url' => get_theme_mod('social_media_youtube'),
			'short_name' => 'Yt.'
		],
		'tumblr' => [
			'url' => get_theme_mod('social_media_tumblr'),
			'short_name' => 'Tm.'
		],
		'linkedin' => [
			'url' => get_theme_mod('social_media_linkedin'),
			'short_name' => 'Lk.'
		],
		'flickr' => [
			'url' => get_theme_mod('social_media_flickr'),
			'short_name' => 'Fl.'
		],
		'spotify' => [
			'url' => get_theme_mod('social_media_spotify'),
			'short_name' => 'Sp.'
		],
		'instagram' => [
			'url' => get_theme_mod('social_media_instagram'),
			'short_name' => 'In.'
		],
	];

	if ($sorter) {
		echo '<ul>';
		foreach ($sorter as $social_media) {
			if ($vara_social_media[$social_media]['url']) {
				echo sprintf(
					'<li><a target="%s" href="%s">%s</a></li>',
					get_theme_mod('social_media_new_window') == '1' ? '_blank' : '_self',
					esc_url($vara_social_media[$social_media]['url']),
					esc_attr($vara_social_media[$social_media]['short_name'])
				);
			}
		}
		echo '</ul>';
	}
}

/**
 * Default Pagination
 *
 * Well organised pagination with numbers and arrows,
 * theme uses it on blogs and portfolios.
 */
if ( !function_exists( 'grada_paging_navigation' ) ) {
	function grada_paging_navigation( $query_object ) {

		// Don't print empty markup if there's only one page.
		if ( $query_object->max_num_pages < 2 ) {
			return;
		}

		$paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
		$pagenum_link = html_entity_decode( get_pagenum_link() );
		$query_args   = array();
		$url_parts    = explode( '?', $pagenum_link );

		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}

		$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
		$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

		$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';

		// Set up paginated links.
		$page_links = paginate_links( array(
			'base'     => $pagenum_link,
			'format'   => $format,
			'total'    => $query_object->max_num_pages,
			'current'  => $paged,
			'mid_size' => 1,
			'add_args' => array_map( 'urlencode', $query_args ),
			'type'      => 'list',
			'prev_text' => '<i class="material-icons">keyboard_arrow_left</i>',
			'next_text' => '<i class="material-icons">keyboard_arrow_right</i>',
		) );

		if ( $page_links ) :
			?>
            <div class="gs-pagination">
                <div class="d-flex align-items-center justify-content-center medium-pt">
					<?php echo wp_kses_post( $page_links ); ?>
                </div>
            </div>

		<?php
		endif;

	}
}


/**
 * Ajax Mini Cart
 *
 * Mini cart will update in
 * the same page, without
 * reloading the current state.
 */
function vara_woocommerce_header_add_to_cart_fragment($fragments) {
	ob_start();
	?>
    <span class="cart-number"><?php echo sprintf('%d', WC()->cart->cart_contents_count); ?></span>
	<?php
	$fragments['.header-shopping-cart .cart-number'] = ob_get_clean();
	return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'vara_woocommerce_header_add_to_cart_fragment');

/**
 * Shop Posts Per Page
 *
 * The number comes from customizer
 * and via woocommerce filter it changes
 * the posts per page of shop page.
 */
if (get_theme_mod('shop_ppp') && class_exists('WooCommerce')) {
	add_filter('loop_shop_per_page', 'vara_loop_shop_per_page', 20);
	function vara_loop_shop_per_page($cols) {
		$cols = get_theme_mod('shop_ppp');
		return $cols;
	}
}

/**
 * Shorten the Excerpt
 */
add_filter('excerpt_length', 'vara_excerpt_shorten', 999);
function vara_excerpt_shorten($length) {
	return 23;
}

/**
 * Excerpt More
 *
 * Remove brackets from dots
 */
add_filter('excerpt_more', 'vara_excerpt_more');
function vara_excerpt_more($more) {
	return '...';
}

/**
 * Body Offset
 */
function vara_body_offset() {
	if (vara_inherit_option('general_body_offset', 'body_offset', '2') == '2' || is_search())  {
		return;
	}

	$vara_offset_output = [];
	$vara_body_offset_padding = [
		'theme-options' => get_theme_mod('body_offset_padding'),
		'acf' => [
			'padding-left' => get_field('general_body_offset_padding_left', get_queried_object()),
			'padding-right' => get_field('general_body_offset_padding_right', get_queried_object())
		]
	];

	if (get_field('general_body_offset', get_queried_object()) == '2') {
		$vara_body_offset_values = $vara_body_offset_padding['acf'];
	} else {
		$vara_body_offset_values = $vara_body_offset_padding['theme-options'];
	}

	$vara_offset_output[] = isset($vara_body_offset_values['padding-left']) && $vara_body_offset_values['padding-left'] != 0 ? 'padding-left:' . $vara_body_offset_values['padding-left'] : '';
	$vara_offset_output[] = isset($vara_body_offset_values['padding-right']) && $vara_body_offset_values['padding-right'] != 0 ? 'padding-right:' . $vara_body_offset_values['padding-right'] : '';

	// Offset Breakpoint
	if (vara_inherit_option('general_body_offset_breakpoint', 'body_offset_breakpoint', '1') == '1') {
		$vara_offset_media_query = '1039px';
	} else {
		$vara_offset_media_query = '745px';
	}

	return $vara_offset_output ? '@media (min-width: '. $vara_offset_media_query .'){ .site-content .gs-content-wrapper, .header-is-sticky .gs-site-header, .site-footer-sticky, .gs-footer-template {' . implode('; ', $vara_offset_output) . '}}' : '';
}

/**
 * Page Background
 */
function vara_page_background() {
    $id = get_queried_object_id();
	$class_prefix = '';

    if ( function_exists( 'is_woocommerce' ) ) {
        if ( is_product() ) {
            $id = get_the_ID();
        }
    }
    if ( is_single() ) {
        $class_prefix = '.postid-' . $id;
    } elseif ( is_home() ) {
        $class_prefix .= '.home';
    } elseif ( is_archive() || $id === get_option( 'woocommerce_shop_page_id' ) ) {
        $class_prefix .= '.archive';
    } elseif ( is_search() ) {
        $class_prefix .= '.search';
    } elseif ( is_404() ) {
        $class_prefix .= '.error404';
    } else {
        $class_prefix .= '.page-id-' . $id;
    }

	$container_selector = array(
		$class_prefix . ' .gs-content-wrapper'
	);

	$container_class        = array();
	$page_background_color  = get_field('page_background_color', get_queried_object());
	$page_background_image  = get_field('page_background_image', get_queried_object());
	$page_background_repeat = get_field('page_background_repeat', get_queried_object());

	if ( ! empty( $page_background_color ) ) {
		$container_class['background-color'] = $page_background_color;
	}

	if ( ! empty( $page_background_image['url'] ) ) {
		$container_class['background-image'] = 'url(' . esc_url( $page_background_image['url'] ) . ')';

		if ( $page_background_repeat === 'yes' ) {
			$container_class['background-repeat']   = 'repeat';
			$container_class['background-position'] = '0 0';
		} else {
			$container_class['background-repeat']   = 'no-repeat';
			$container_class['background-position'] = 'center 0';
			$container_class['background-size']     = 'cover';
		}
	}

	$current_style = ozark_dynamic_css( $container_selector, $container_class );

	return $current_style;
}
/**
 * Get WooCommerce excerpt and shorten character length
 */
function vara_get_woocommerce_excerpt() {
	$excerpt = get_the_excerpt();
	$excerpt = preg_replace( " ([.*?])", '', $excerpt );
	$excerpt = strip_shortcodes( $excerpt );
	$excerpt = strip_tags( $excerpt );
	$excerpt = substr( $excerpt, 0, 140 );
	$excerpt = substr( $excerpt, 0, strripos( $excerpt, " " ) );

	return $excerpt;
}