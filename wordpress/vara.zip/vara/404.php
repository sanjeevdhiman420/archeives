<?php
/**
 * 404
 */
get_header();

/**
 * Hero
 */
$vara_404_hero_style = $vara_404_overlay_style = [];

/**
 * Image
 */
if (get_theme_mod('404_hero_image')) {
	$vara_404_hero_style[] = 'background-image: url('. esc_url(wp_get_attachment_url(get_theme_mod('404_hero_image'))) .')';
}

/**
 * Overlay
 */
if (get_theme_mod('404_hero_overlay', '2') == '1') {
	if (get_theme_mod('404_hero_overlay_opacity')) {
		$vara_404_overlay_style[] = 'opacity: '. get_theme_mod('404_hero_overlay_opacity') .'';
	}

	if (get_theme_mod('404_hero_overlay_color')) {
		$vara_404_overlay_style[] = 'background-color: '. get_theme_mod('404_hero_overlay_color') .'';
	}
}

echo sprintf(
	'<div class="gs-page-404">
        <div class="gs-page-heading-outer d-flex">
            <div class="gs-page-heading-bg">
                <div class="gs-page-heading-bg-img" %s></div>
                %s
            </div>
            <div class="gs-page-heading-inner align-self-center">
                <div class="container">
                    <div class="row">
                    	<div class="col-lg-6 page-404-content offset-lg-3 gs-text-center">
	                        <div class="gs-page-heading-title gsFadeIn wow"><h1>%s</h1></div>
		                    <div class="gs-page-heading-description gsFadeIn wow"><p>%s</p></div>
		                    <a href="%s" class="gs-btn gs-btn-regular gs-btn-dark gsFadeIn wow">%s</a>
						</div>
					</div>
                </div>
            </div>
        </div>
        <span class="gs-error-code">404</span>
    </div>',
	$vara_404_hero_style ? 'style="'. implode(';', $vara_404_hero_style) .'"' : '',
	get_theme_mod('404_hero_overlay', '2') == '1' ? '<div class="gs-page-heading-bg-overlay" style="'. implode(';', $vara_404_overlay_style) .'"></div>' : '',
	get_theme_mod('404_title') ? get_theme_mod('404_title') : esc_html__('Oops! That page can’t be found.', 'vara'),
	get_theme_mod('404_description') ? get_theme_mod('404_description') : esc_html__('The page you are looking for might have beeen removed had it\'s name changed or is temporarily unavailable.', 'vara'),
	get_theme_mod('404_button_url') ? get_theme_mod('404_button_url') : esc_url(home_url('/')),
	get_theme_mod('404_button_text') ? get_theme_mod('404_button_text') : esc_attr__('Go to Homepage', 'vara')
);

get_footer();