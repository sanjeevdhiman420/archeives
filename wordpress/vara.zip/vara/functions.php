<?php
/**
 * Global Constants
 */

define('VARA_THEME_DIR', get_template_directory());
define('VARA_THEME_URI', get_template_directory_uri());
define('VARA_THEME_STYLESHEET', get_stylesheet_uri());
define('VARA_THEME_PLACEHOLDER', get_template_directory_uri() . '/assets/images/placeholder.png');
define('VARA_THEME_NAME', 'vara');
define('VARA_THEME_VERSION', wp_get_theme()->get('Version'));

/**
 * Content Width
 */
!isset($content_width) ? $content_width = 1920 : '';

/**
 * Text Domain
 */
load_theme_textdomain('vara', VARA_THEME_DIR . '/languages');

require get_parent_theme_file_path ( '/inc/lib/nav-menu/main-menu.php' );

// Action to call init
add_action('after_setup_theme', 'vara_init');

/**
 * Ozark Init
 */
function vara_init() {
	# Theme Support
	add_theme_support('title-tag');
	add_theme_support('widgets');
	add_theme_support('automatic-feed-links');
	add_theme_support('post-thumbnails');
	add_theme_support('featured-image');

	// WooCommerce Theme Support
	if (class_exists('WooCommerce')) {
		add_theme_support('woocommerce');
		add_theme_support('wc-product-gallery-zoom');
		add_theme_support('wc-product-gallery-lightbox');
		add_theme_support('wc-product-gallery-slider');
	}

	# HTML5 Galleries
	add_theme_support( 'html5', array( 'gallery', 'caption', 'style', 'script' ) );

	// Include custom files
	include(VARA_THEME_DIR . '/inc/grada-functions.php');
	include(VARA_THEME_DIR . '/inc/grada-custom-style.php');
	include_once(VARA_THEME_DIR . '/inc/lib/class-tgm-plugin-activation.php');
	include_once(VARA_THEME_DIR . '/inc/acf-fields.php');
	get_theme_mod('custom_fields_panel', '2') == '2' ? define('ACF_LITE' , true) : '';

	// Theme actions within init function
	add_action('tgmpa_register', 'vara_plugins');
	add_action('wp_enqueue_scripts', 'vara_register_styles');
	add_action('wp_enqueue_scripts', 'vara_register_scripts');
	add_action('admin_enqueue_scripts', 'vara_admin_scripts');
	add_action('widgets_init', 'vara_register_sidebars');

	// Theme Filters
	if (class_exists('Kirki')){
		add_filter('kirki_telemetry', '__return_false');
	}

	// Register Menus
	register_nav_menus(
		array(
			'main-menu' => esc_html__('Main Menu', 'vara')
		)
	);
}

/**
 * TGMPA Include Plugins
 */
function vara_plugins() {

	$plugins = array(
		array(
			'name'      => esc_html__('Advanced Custom Fields', 'vara'),
			'slug'      => 'advanced-custom-fields',
			'required'  => true
		),
		array(
			'name'      => esc_html__('Elementor', 'vara'),
			'slug'      => 'elementor',
			'required'  => true
		),
		array(
			'name'      => esc_html__('Revolution Slider', 'vara'),
			'slug'      => 'revslider',
			'source'    => get_template_directory() . '/inc/plugins/revslider.zip',
			'required'  => false
		),
		array(
			'name'        => esc_html__('Vara Plugin', 'vara'),
			'slug'        => 'vara-plugin',
			'source'    	=> get_template_directory() . '/inc/plugins/vara-plugin.zip',
			'required'    => true
		),
		array(
			'name'      => esc_html__('WooCommerce', 'vara'),
			'slug'      => 'woocommerce',
			'required'  => false
		),
		array(
			'name'       => esc_html__('One Click Demo Import', 'vara'),
			'slug'       => 'one-click-demo-import',
			'required'   => false
		),
		array(
			'name'       => esc_html__('Contact Form 7', 'vara'),
			'slug'       => 'contact-form-7',
			'required'   => false
		)
	);

	$config = array(
		'id'           => 'tgmpa',
		'default_path' => '',
		'menu'         => 'tgmpa-install-plugins',
		'parent_slug'  => 'themes.php',
		'capability'   => 'edit_theme_options',
		'has_notices'  => true,
		'dismissable'  => true,
		'dismiss_msg'  => '',
		'is_automatic' => false,
		'message'      => ''
	);
	tgmpa($plugins, $config);
}

/**
 * Ozark CSS
 */
function vara_register_styles() {
	wp_enqueue_style('vara-main-style', VARA_THEME_URI . '/assets/css/vara.css', false,VARA_THEME_VERSION, null);
	wp_enqueue_style('magnific-popup', VARA_THEME_URI . '/assets/css/magnific-popup.css', false, VARA_THEME_VERSION, null);
	wp_enqueue_style('owl-carousel', VARA_THEME_URI . '/assets/css/owl.carousel.min.css', false, VARA_THEME_VERSION, null);
	wp_enqueue_style('perfect-scrollbar', VARA_THEME_URI . '/assets/css/perfect-scrollbar.css', false, VARA_THEME_VERSION, null);
	wp_enqueue_style('select2');
	wp_enqueue_style('elegant-icons', VARA_THEME_URI . '/assets/css/elegant-icons.css', false, VARA_THEME_VERSION, null);
	wp_enqueue_style('material-icons', '//fonts.googleapis.com/icon?family=Material+Icons');
	wp_enqueue_style('vara-style', VARA_THEME_STYLESHEET);

	if (is_rtl()) {
		wp_enqueue_style('style-rtl', VARA_THEME_URI . '/assets/css/style-rtl.css' );
	}

	// Custom Style and Fonts
	if (function_exists('grada_color_lightness') && function_exists('grada_hexToRgb')) {
		wp_add_inline_style('vara-style', vara_custom_style());
	}

	wp_add_inline_style('vara-style', vara_body_offset());
	wp_add_inline_style('vara-style', vara_page_background());
}

/**
 * Ozark JS
 */
function vara_register_scripts() {
	if ( ! is_admin() ) {
		wp_enqueue_script('isotope', VARA_THEME_URI . '/assets/js/isotope.pkgd.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('packery-mode', VARA_THEME_URI . '/assets/js/packery-mode.pkgd.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('magnific-popup', VARA_THEME_URI . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('owl-carousel', VARA_THEME_URI . '/assets/js/owl.carousel.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('typed', VARA_THEME_URI . '/assets/js/typed.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('select2' );
		wp_enqueue_script('wow', VARA_THEME_URI . '/assets/js/wow.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('theia-sticky-sidebar', VARA_THEME_URI . '/assets/js/theia-sticky-sidebar.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('headroom', VARA_THEME_URI . '/assets/js/headroom.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('headroom-zepto', VARA_THEME_URI . '/assets/js/jQuery.headroom.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('perfect-scrollbar', VARA_THEME_URI . '/assets/js/perfect-scrollbar.min.js', array('jquery'), VARA_THEME_VERSION, TRUE);
		wp_enqueue_script('vara-js', VARA_THEME_URI . '/assets/js/vara.js', array('jquery'), VARA_THEME_VERSION, TRUE);

		if ( ( ! is_admin() ) && is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
}

/**
 * Dynamic CSS
 */
function ozark_dynamic_css($selector, $rules) {
	$output = '';
	//check if selector and rules are valid data
	if (!empty($selector) && (is_array($rules) && count($rules))) {

		if (is_array($selector) && count($selector)) {
			$output .= implode(', ', $selector);
		} else {
			$output .= $selector;
		}

		$output .= ' { ';
		foreach ($rules as $prop => $value) {
			if ($prop !== '') {
				$output .= $prop . ': ' . esc_attr($value) . ';';
			}
		}

		$output .= '}';
	}

	return $output;
}

if ( ! function_exists( 'vara_get_google_fonts_url' ) ) {
	/**
	 * Load/Get Google Fonts Url
	 */
	function vara_google_fonts_url( $fonts ) {
		$font_url = '';

		$font_url = add_query_arg( 'family', urlencode( $fonts ), "//fonts.googleapis.com/css" );

		return $font_url;
	}
}

/**
 * Enqueue google fonts
 */
function vara_enqueue_google_fonts() {
	$body_google_fonts = 'Overpass:300,300i,400,400i,500,600,700';

	wp_enqueue_style( 'google-font-overpass', vara_google_fonts_url( $body_google_fonts ), array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'vara_enqueue_google_fonts', 10000 );

/**
 * Enqueue Extra Scripts
 */
function vara_admin_scripts() {
	wp_enqueue_style('vara-admin-style', VARA_THEME_URI . '/inc/admin/assets/style.css', false, VARA_THEME_VERSION, null);
	wp_enqueue_script('vara-admin-script', VARA_THEME_URI . '/inc/admin/assets/script.js', array('jquery'), VARA_THEME_VERSION, TRUE);
}

/**
 * Register Sidebar (Widgets Area)
 */
function vara_register_sidebars() {

	$vara_sidebars = [
		[
			'name' => esc_html__('Main Sidebar', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are displayed in Blog Page.', 'vara'),
			'id' => 'main-sidebar'
		],
		[
			'name' => esc_html__('Shop Sidebar', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are displayed in Shop Pages.', 'vara'),
			'id' => 'shop-sidebar',
			'condition' => class_exists('WooCommerce')
		],
		[
			'name' => esc_html__('Footer Sidebar 1', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the first column of footer.', 'vara'),
			'id' => 'sidebar-footer-1'
		],
		[
			'name' => esc_html__('Footer Sidebar 2', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the second column of footer.', 'vara'),
			'id' => 'sidebar-footer-2'
		],
		[
			'name' => esc_html__('Footer Sidebar 3', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the third column of footer.', 'vara'),
			'id' => 'sidebar-footer-3'
		],
		[
			'name' => esc_html__('Footer Sidebar 4', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the fourth column of footer.', 'vara'),
			'id' => 'sidebar-footer-4'
		],
		[
			'name' => esc_html__('Footer Sidebar 5', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the fifth column of footer.', 'vara'),
			'id' => 'sidebar-footer-5'
		],
		[
			'name' => esc_html__('Footer Sidebar 6', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the sixth column of footer.', 'vara'),
			'id' => 'sidebar-footer-6'
		],
		[
			'name' => esc_html__('Off-Canvas Sidebar', 'vara'),
			'description' => esc_html__('Widgets on this sidebar are placed on the sliding bar of header.', 'vara'),
			'id' => 'off-canvas-sidebar',
		],
	];

	if (get_theme_mod('general_sidebars')) {
		foreach (get_theme_mod('general_sidebars') as $sidebar) {
			$vara_sidebars[] = [
				'name' => esc_html__($sidebar['sidebar_title'], 'vara'),
				'description' => esc_html__($sidebar['sidebar_description'], 'vara'),
				'id' => strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $sidebar['sidebar_title']))),
			];
		}
	}

	foreach ($vara_sidebars as $sidebar) {
		$sidebar['condition'] = isset($sidebar['condition']) ? $sidebar['condition'] : true;

		if ($sidebar['condition'] == false) {
			continue;
		}

		register_sidebar(
			[
				'name' => esc_html($sidebar['name']),
				'description' => esc_html($sidebar['description']),
				'id' => esc_attr($sidebar['id']),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-title-outer"><h5 class="widgettitle">',
				'after_title'   => '</h5></div>'
			]
		);
	}
}


/**
 * WooCommerce Placeholder
 */
add_filter('woocommerce_placeholder_img_src', 'vara_woocommerce_placeholder_image');
function vara_woocommerce_placeholder_image($src) {
	$src = VARA_THEME_PLACEHOLDER;

	return $src;
}

/**
 * Custom Template
 */
function vara_get_custom_template($id) {
	if (!class_exists('Elementor\Plugin')) {
		return;
	}

	if (empty($id)) {
		return;
	}

	$content = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($id, true);

	return $content;
}

/**
 * Custom Body Classes
 */
function vara_custom_body_classes($classes) {
	/**
	 * Theme Borders
	 */
	if (vara_inherit_option('theme_borders', 'theme_borders', '2') == '1' && apply_filters('vara_display_theme_borders', true)) {
		$classes[] = 'gs-page-boundary-on';
	}

	/**
	 * Parallax Footer
	 */
	if (vara_inherit_option('footer_parallax', 'footer_parallax', '2') == '1') {
		$classes[] = 'sticky-footer-on';
	}

	return $classes;
}
add_filter('body_class', 'vara_custom_body_classes');

/**
 * Mega Menu Classes
 *
 * Add classes to the menu item when
 * mega menu option is clicked.
 */
add_filter('wp_nav_menu_objects', 'vara_mega_menu_class', 10, 2);
function vara_mega_menu_class($items, $args) {
	foreach ($items as $item) {
		// Activate
		if (get_field('mega_menu', $item)) {
			$item->classes[] = 'menu-mega-dropdown';
		}

		// Columns
		switch (get_field('mega_menu_columns', $item)) {
			case '1':
				$item->classes[] = 'megamenu-2-col';
				break;
			case '2':
				$item->classes[] = 'megamenu-3-col';
				break;
			case '3':
				$item->classes[] = 'megamenu-4-col';
				break;
			case '4':
				$item->classes[] = 'megamenu-5-col';
				break;
		}

		// Unclickable
		if (get_field('menu_unclickable', $item)) {
			$item->classes[] = 'disabled';
		}

		// Label
		if (get_field('menu_label', $item) == '2') {
			$item->classes[] = 'gs-menu-label gs-menu-label-new';
		} elseif (get_field('menu_label', $item) == '3') {
			$item->classes[] = 'gs-menu-label gs-menu-label-hot';
		}
	}
	return $items;
}

/**
 * Remove Mega Menu Classes
 *
 * Remove clases from the menu
 * items, useful for builder.
 */
function vara_remove_mega_menu_class($items, $args) {
	foreach ($items as $item) {
		foreach($item->classes as $key => $class) {
			if(strpos($class, 'menu-mega-dropdown') !== false) {
				unset($item->classes[$key]);
			}
		}
	}
	return $items;
}

/**
 * Rewrite the ACF functions incase ACF fails to activate
 */
if (!function_exists('get_field') && !is_admin() && !function_exists('get_sub_field')) {
	function get_field($field_id, $post_id = null) {
		return null;
	}

	function get_sub_field($field_id, $post_id = null){
		return null;
	}
}

/**
 * Demo Importer
 *
 * Import the content, widgets and
 * the customizer settings via the
 * plugin one click demo importer.
 */
add_filter('pt-ocdi/import_files', 'vara_ocdi_import_files');
function vara_ocdi_import_files() {
	return array(
		array(
			'import_file_name'           => esc_html__('Main Demo', 'vara'),
			'categories'                 => array('Demo'),
			'import_file_url'            => 'https://demo.gradastudio.com/vara/content.xml',
			'import_widget_file_url'     => 'https://demo.gradastudio.com/vara/widgets.wie',
			'import_customizer_file_url' => 'https://demo.gradastudio.com/vara/customizer.dat',
			'import_notice'              => esc_html__('Everything that is listed in our demo will be imported.', 'vara'),
		),
		array(
			'import_file_name'           => esc_html__('Header Templates', 'vara'),
			'categories'                 => array('Templates'),
			'import_file_url'            => 'https://demo.gradastudio.com/vara/header-templates.xml',
			'import_preview_image_url'   => VARA_THEME_URI . '/assets/images/sc-headers.png',
			'import_notice'              => esc_html__('Only the Header Templates will be imported.', 'vara'),
		),
	);
}

/**
 * After Import Setup
 *
 * Set the Classic Home Page as front
 * page and assign the menu to
 * the main menu location.
 */
add_action('pt-ocdi/after_import', 'vara_ocdi_after_import_setup');
function vara_ocdi_after_import_setup() {
	$main_menu = get_term_by('name', 'Main Menu', 'nav_menu');

	if ($main_menu) {
		set_theme_mod('nav_menu_locations', array('main-menu' => $main_menu->term_id));
	}

	// Front Page
	$front_page_id = get_page_by_title('Main Home');
	if ($front_page_id) {
		update_option('page_on_front', $front_page_id->ID);
		update_option('show_on_front', 'page');
	}
	$blog_page_id = get_page_by_title('Blog');
	if ($blog_page_id) {
		update_option('page_for_posts', $blog_page_id->ID);
	}

	//Import Revolution Slider
	if ( class_exists( 'RevSlider' ) ) {
		$slider_array = array(
			get_template_directory()."/demo/main-home.zip",
			get_template_directory()."/demo/fullscreen-slider.zip",
			get_template_directory()."/demo/portfolio-minimal.zip",
			get_template_directory()."/demo/shop-home.zip"
		);

		$slider = new RevSlider();

		foreach($slider_array as $filepath){
			$slider->importSliderFromPost(true,true,$filepath);
		}

		echo ' Slider processed';
	}
}