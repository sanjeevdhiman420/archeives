<?php get_header();

get_template_part('tpls/hero/standard');

if (get_theme_mod('blog_title') || get_theme_mod('blog_content')) :
?>
   <div class="container">
        <div class="large-pt">
            <h2 class="gs-page-title"><?php echo esc_attr(get_theme_mod('blog_title')) ?></h2>
            <?php echo wpautop(wp_kses_post(get_theme_mod('blog_content'))) ?>
        </div>
   </div>
<?php
endif;

get_template_part('tpls/blog/loop'); ?>

<?php get_footer(); ?>
