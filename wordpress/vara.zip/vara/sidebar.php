<?php
/**
 * Main Sidebar
 */
if (is_active_sidebar('main-sidebar')) {
	dynamic_sidebar('main-sidebar');
}
