<?php
/**
 * Search Page
 */

get_header();

/**
 * Arguments
 *
 * Modify the query with
 * different arguments properties.
 */
$args = array_merge(
	$wp_query->query_vars,
	array('post_type' =>
		      get_theme_mod('search_post_types', ['post', 'page', 'portfolio', 'product'])
	)
);

$query = new WP_Query($args);

/**
 * Columns
 */
$vara_search_item_class = 'iso-item';

switch (get_theme_mod('search_columns', '3')) {
	case '1':
		$vara_search_item_class .= ' col-12';
		break;
	case '2':
		$vara_search_item_class .= ' col-sm-6';
		break;
	default:
		$vara_search_item_class .= ' col-md-4 col-sm-6';
		break;
	case '4':
		$vara_search_item_class .= ' col-md-3 col-sm-6';
		break;
}

/**
 * Sidebar
 *
 * Three different options for sidebar
 * two are for placements on the left
 * and the right and the other one to
 * hide the sidebar.
 */
$vara_search_row_class = 'row';
$vara_search_posts_class = 'col-lg-8';
$vara_search_sidebar_class = 'col-lg-4';

if (get_theme_mod('search_sidebar', '3') == '1') {
	$vara_search_row_class .= ' flex-row-reverse';
} elseif (get_theme_mod('search_sidebar', '3') == '3') {
	$vara_search_posts_class = 'col-12';
	$vara_search_sidebar_class = 'gs-d-none';
}

/**
 * Hero
 */
$vara_search_hero_style = $vara_search_overlay_style = [];

/**
 * Image
 */
if (get_theme_mod('search_hero_image')) {
	$vara_search_hero_style[] = 'background-image: url('. esc_url(wp_get_attachment_url(get_theme_mod('search_hero_image'))) .')';
}

/**
 * Overlay
 */
if (get_theme_mod('search_hero_overlay', '2') == '1') {
	if (get_theme_mod('search_hero_overlay_opacity')) {
		$vara_search_overlay_style[] = 'opacity: '. get_theme_mod('search_hero_overlay_opacity') .'';
	}

	if (get_theme_mod('search_hero_overlay_color')) {
		$vara_search_overlay_style[] = 'background-color: '. get_theme_mod('search_hero_overlay_color') .'';
	}
}

vara_breadcrumbs(1, get_theme_mod('breadcrumbs_separator'));
?>
<?php if (!$query->have_posts()) : ?>
	<div class="gs-search-page huge-pt huge-pb">
		<div class="container">
			<h1><?php echo wp_kses_post(__('Sorry, no results were found.', 'vara')) ?></h1>
			<p><?php echo wp_kses_post(__('Please try again with different keywords.', 'vara')) ?></p>
			<?php get_search_form() ?>
		</div>
	</div>
<?php endif; ?>
<?php if ($query->have_posts()) : ?>
	<div class="gs-blog-wrapper gs-entries-style-classic-grid large-pt large-pb">
		<div class="container">
			<div class="<?php echo esc_attr($vara_search_row_class) ?>">
				<div class="gs-blog-holder-inner <?php echo esc_attr($vara_search_posts_class) ?>">
					<div class="row isotope-container">
						<?php while ($query->have_posts()) : $query->the_post() ?>
							<article <?php post_class($vara_search_item_class) ?> id="id-<?php the_ID() ?>" data-id="<?php the_ID() ?>">
								<div class="gs-blog-item gsFadeIn wow">
                                    <div class="gs-blog-post gs-blog-post--classic-grid">
                                        <div class="entry-details">
                                            <div class="entry-details__inner">
                                                <div class="entry-details-meta">
                                                    <span class="entry-meta-category gs-divider">
                                                        <span><?php echo esc_attr(get_post_type()) ?></span>
                                                    </span>
                                                </div>
                                                <h3 class="entry-details-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	                                            <?php the_excerpt() ?>
                                                <a class="gs-read-more" href="<?php the_permalink() ?>">
                                                    <span class="text"><?php echo esc_html__('Read More', 'vara') ?></span>
                                                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 22 12" style="enable-background:new 0 0 22 12;" xml:space="preserve"><line x1="0.3" y1="6" x2="21.3" y2="6"></line><polyline points="15.8,0.6 21.3,6 15.8,11.4 "></polyline></svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
							</article>
						<?php endwhile; ?>
					</div>
                    <?php grada_paging_navigation($wp_query); ?>
				</div>
				<?php if (get_theme_mod('search_sidebar', '3') !== '3') : ?>
					<div class="<?php echo esc_attr($vara_search_sidebar_class) ?>">
						<div class="sidebar-container archive-sidebar">
							<?php get_sidebar() ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php
endif; wp_reset_postdata();

get_footer();