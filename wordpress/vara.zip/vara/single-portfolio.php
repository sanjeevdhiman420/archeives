<?php
/**
 * Portfolio Single
 */
get_header();

get_template_part('tpls/hero/standard');

/**
 * Breadcrumb
 */
$vara_page_breadcrumb = vara_inherit_option('general_breadcrumb', 'breadcrumbs_portfolio_item_visibility', '2');
vara_breadcrumbs($vara_page_breadcrumb, get_theme_mod('breadcrumbs_separator'));

if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
		<?php if (get_field('portfolio_item_type') != '3') : ?>
			<div class="container">
				<div class="gs-portfolio-single-item large-pt large-pb">
					<?php
					// Portfolio Item Type
					if (get_field('portfolio_item_type') == '1') {
						get_template_part('tpls/portfolio-item/type/side');
					} elseif (get_field('portfolio_item_type') == '2') {
						get_template_part('tpls/portfolio-item/type/vertical');
					}
					?>
				</div>
			</div>
		<?php endif; ?>
		<?php get_field('portfolio_item_type') == '3' ? the_content() : '' ?>
	<?php endwhile;
endif;

/**
 * Related
 */
$vara_related_template = get_field('related_posts') == '2' ? get_field('related_posts_template') : get_theme_mod('portfolio_item_related_template');

if (vara_inherit_option('related_posts', 'portfolio_item_related', '2') == '1' && $vara_related_template) {
	echo vara_get_custom_template($vara_related_template);
}

// Item Navigation
get_template_part('tpls/portfolio-item/navigation');

get_footer();