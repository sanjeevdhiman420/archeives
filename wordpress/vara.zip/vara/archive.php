<?php
/**
 * Archive Page
 */
get_header();

get_template_part('tps/hero/taxonomy');

/**
 * Breadcrumb
 */
$vara_page_breadcrumb = vara_inherit_option('general_archive_breadcrumb', 'breadcrumbs_archives_visibility', '2');
vara_breadcrumbs($vara_page_breadcrumb, get_theme_mod('breadcrumbs_separator'));

get_template_part('tpls/blog/loop');

get_footer();