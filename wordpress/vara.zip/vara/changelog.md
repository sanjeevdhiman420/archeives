## 1.2
FIXED: Portfolio Category Navigation
UPDATE: Slider Revolution plugin updated to the latest version in theme package
NEW: WordPress 5.7.2 compatibility added
NEW: WooCommerce 4.8 compatibility added

## 1.1
FIXED: Blog, Portfolio masonry not working in WordPress 5.6
FIXED: Blog Filters improvements
FIXED: Demo Content updated to latest version
FIXED: Minor bug fixes and improvements

NEW: WordPress 5.6 compatibility added
NEW: WooCommerce 4.8 compatibility added

UPDATE: Ozark Plugin updated to latest version
UPDATE: Slider Revolution plugin updated to the latest version in theme package